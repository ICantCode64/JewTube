<?php
include __DIR__ . '/../core/main.php';

$userId = $_SESSION['userid'] ?? "";

if (!$loggedin) {
	header("Location: /login.php");
	exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$title = SafeVar($_POST['title'] ?? "");
	$description = SafeVar($_POST['description'] ?? "");

	if ($title == "") {
		$error = "Title is required.";
	} elseif (!isset($_FILES['video']) || $_FILES['video']['error'] != 0) {
		$error = "Video file is required.";
	} else {

		$file = $_FILES['video'];

		$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
		$allowed = ['mp4', 'webm', 'mov'];

		if (!in_array($ext, $allowed)) {
			$error = "Only MP4, WEBM, and MOV files are allowed.";
		} else {

			$videoId = uniqid();
			$filename = $videoId . "." . $ext;

			$uploadDir = __DIR__ . "/../uploads/videos/";
			$thumbDir = __DIR__ . "/../uploads/video_thumbnails/";

			if (!is_dir($uploadDir)) {
				mkdir($uploadDir, 0777, true);
			}

			if (!is_dir($thumbDir)) {
				mkdir($thumbDir, 0777, true);
			}

			$uploadPath = $uploadDir . $filename;

			if (move_uploaded_file($file['tmp_name'], $uploadPath)) {

				$thumbPath = $thumbDir . $videoId . ".png";

				$ffmpeg = "ffmpeg";

				$cmd =
					'"' . $ffmpeg . '" -y ' .
					'-ss 00:00:05 ' .
					'-i "' . $uploadPath . '" ' .
					'-frames:v 1 ' .
					'"' . $thumbPath . '" 2>&1';

				$output = [];
				$returnCode = 0;

				exec($cmd, $output, $returnCode);

				if ($returnCode !== 0 || !file_exists($thumbPath)) {
					$error = "Thumbnail failed: " . implode("\n", $output);
				} else {

					SqlQuery("
						INSERT INTO videos (
							authorid,
							name,
							description,
							filename,
							views,
							published_at
						)
						VALUES (
							'$userId',
							'$title',
							'$description',
							'$filename',
							0,
							NOW()
						)
					");
					$rvideoid = $conn->insert_id;
					header("Location: /watch.php?id=$rvideoid");
					exit;
				}

			} else {
				$error = "Upload failed.";
			}
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Upload - <?= $sitename; ?> Studio</title>

	<?php include __DIR__ . '/../main/global.php'; ?>

	<style>
	.studio-page {
		padding: 24px;
		width: 100%;
		background: #f9f9f9;
	}

	.studio-layout {
		max-width: 900px;
		margin: 0 auto;
	}

	.studio-title {
		font-size: 26px;
		font-weight: normal;
		margin: 0 0 22px;
		color: #111;
	}

	.upload-box {
		background: white;
		border: 1px solid #ddd;
		padding: 24px;
	}

	.form-row {
		margin-bottom: 18px;
	}

	.form-row label {
		display: block;
		font-size: 13px;
		color: #555;
		margin-bottom: 6px;
	}

	.input,
	.textarea {
		width: 100%;
		border: 1px solid #ccc;
		padding: 9px;
		font-size: 14px;
		box-sizing: border-box;
	}

	.textarea {
		min-height: 130px;
		resize: vertical;
		font-family: inherit;
	}

	.file-input {
		border: 1px dashed #bbb;
		background: #fafafa;
		padding: 20px;
		width: 100%;
		box-sizing: border-box;
	}

	.submit-row {
		display: flex;
		justify-content: flex-end;
		gap: 10px;
		margin-top: 20px;
	}

	.btn {
		border: 1px solid #ccc;
		background: #f1f1f1;
		padding: 9px 16px;
		font-size: 13px;
		cursor: pointer;
	}

	.upload-btn {
		background: #cc0000;
		border-color: #cc0000;
		color: white;
	}

	.error {
		background: #ffecec;
		border: 1px solid #e0a0a0;
		color: #a00;
		padding: 12px;
		margin-bottom: 18px;
		font-size: 13px;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/../main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/../main/sidebar.php'; ?>

		<main class="studio-page">

			<div class="studio-layout">

				<h1 class="studio-title">Upload video</h1>

				<div class="upload-box">

					<?php if ($error != "") { ?>
						<div class="error">
							<?= htmlspecialchars($error); ?>
						</div>
					<?php } ?>

					<form method="POST" enctype="multipart/form-data">

						<div class="form-row">
							<label>Video file</label>

							<input
								class="file-input"
								type="file"
								name="video"
								accept="video/mp4,video/webm,video/quicktime"
								required
							>
						</div>

						<div class="form-row">
							<label>Title</label>

							<input
								class="input"
								type="text"
								name="title"
								maxlength="120"
								required
							>
						</div>

						<div class="form-row">
							<label>Description</label>

							<textarea
								class="textarea"
								name="description"
								placeholder="Tell viewers about your video"
							></textarea>
						</div>

						<div class="submit-row">

							<button
								class="btn"
								type="button"
								onclick="Redirect('/studio/videos.php')"
							>
								Cancel
							</button>

							<button class="btn upload-btn" type="submit">
								Upload
							</button>

						</div>

					</form>

				</div>

			</div>

		</main>

	</div>

</body>
</html>