<?php
include __DIR__ . '/../core/main.php';

$userId = $_SESSION['userid'] ?? "";

if (!$loggedin) {
	header("Location: /login.php");
	exit;
}

$videoId = $_GET['id'] ?? "";

if (!$videoId) {
	die("Invalid video.");
}

$video = SqlQuery("
	SELECT *
	FROM videos
	WHERE videoid = '$videoId'
	AND authorid = '$userId'
	LIMIT 1
");

if ($video->num_rows == 0) {
	die("Video not found.");
}

$video = $video->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$name = mysqli_real_escape_string($conn, $_POST['name'] ?? "");
	$description = mysqli_real_escape_string($conn, $_POST['description'] ?? "");

	SqlQuery("
		UPDATE videos
		SET
			name = '$name',
			description = '$description'
		WHERE videoid = '$videoId'
	");

	header("Location: /studio/videos.php");
	exit;
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit Video - <?= $sitename; ?> Studio</title>

	<?php include __DIR__ . '/../main/global.php'; ?>

	<style>
	.studio-page {
		padding: 24px;
		width: 100%;
		background: #f9f9f9;
	}

	.studio-layout {
		max-width: 900px;
		margin: 0 auto;
	}

	.page-title {
		font-size: 26px;
		font-weight: normal;
		margin-bottom: 22px;
		color: #111;
	}

	.edit-box {
		background: white;
		border: 1px solid #ddd;
		padding: 22px;
	}

	.form-group {
		margin-bottom: 18px;
	}

	.form-label {
		display: block;
		font-size: 13px;
		color: #666;
		margin-bottom: 6px;
	}

	.form-input,
	.form-textarea {
		width: 100%;
		border: 1px solid #ccc;
		padding: 10px;
		font-size: 14px;
		font-family: Arial, sans-serif;
		box-sizing: border-box;
	}

	.form-textarea {
		height: 160px;
		resize: vertical;
	}

	.thumb-preview {
		width: 320px;
		height: 180px;
		background: #111;
		overflow: hidden;
		margin-bottom: 20px;
	}

	.thumb-preview img {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
	}

	.save-btn {
		background: #065fd4;
		color: white;
		border: 1px solid #065fd4;
		padding: 10px 18px;
		font-size: 14px;
		cursor: pointer;
	}

	.save-btn:hover {
		background: #044eb1;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/../main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/../main/sidebar.php'; ?>

		<main class="studio-page">

			<div class="studio-layout">

				<h1 class="page-title">Edit video</h1>

				<div class="edit-box">

					<div class="thumb-preview">
						<img src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>">
					</div>

					<form method="POST">

						<div class="form-group">
							<label class="form-label">Title</label>

							<input
								type="text"
								name="name"
								class="form-input"
								maxlength="100"
								value="<?= htmlspecialchars($video['name']); ?>"
								required
							>
						</div>

						<div class="form-group">
							<label class="form-label">Description</label>

							<textarea
								name="description"
								class="form-textarea"
							><?= htmlspecialchars($video['description']); ?></textarea>
						</div>

						<button type="submit" class="save-btn">
							Save changes
						</button>

					</form>

				</div>

			</div>

		</main>

	</div>

</body>
</html>