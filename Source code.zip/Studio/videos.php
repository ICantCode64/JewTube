<?php
include __DIR__ . '/../core/main.php';

$userId = $_SESSION['userid'] ?? "";

if (!$loggedin) {
	header("Location: /login.php");
	exit;
}

$videos = SqlQuery("
	SELECT *
	FROM videos
	WHERE authorid = '$userId'
	ORDER BY published_at DESC
");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Videos - <?= $sitename; ?> Studio</title>

	<?php include __DIR__ . '/../main/global.php'; ?>

	<style>
	.studio-page {
		padding: 24px;
		width: 100%;
		background: #f9f9f9;
	}

	.studio-layout {
		max-width: 1100px;
		margin: 0 auto;
	}

	.studio-title {
		font-size: 26px;
		font-weight: normal;
		margin: 0 0 22px;
		color: #111;
	}

	.studio-section {
		background: white;
		border: 1px solid #ddd;
	}

	.section-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 14px 16px;
		border-bottom: 1px solid #ddd;
	}

	.section-header h2 {
		font-size: 18px;
		font-weight: normal;
		margin: 0;
		color: #111;
	}

	.upload-btn {
		background: #cc0000;
		border: 1px solid #cc0000;
		color: white;
		padding: 8px 14px;
		font-size: 13px;
		cursor: pointer;
	}

	.video-table {
		width: 100%;
		border-collapse: collapse;
	}

	.video-table th {
		text-align: left;
		font-weight: normal;
		color: #666;
		font-size: 13px;
		padding: 10px 14px;
		border-bottom: 1px solid #ddd;
	}

	.video-table td {
		padding: 12px 14px;
		border-bottom: 1px solid #eee;
		font-size: 13px;
		color: #333;
		vertical-align: middle;
	}

	.video-table tr:last-child td {
		border-bottom: none;
	}

	.video-info {
		display: flex;
		align-items: center;
		gap: 12px;
	}

	.video-thumb {
		width: 120px;
		height: 68px;
		background: #111;
		flex-shrink: 0;
		overflow: hidden;
	}

	.video-thumb img {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
	}

	.video-name {
		font-size: 14px;
		color: #111;
		margin-bottom: 5px;
	}

	.video-desc {
		color: #777;
		font-size: 12px;
		max-width: 360px;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.action-link {
		color: #065fd4;
		margin-right: 10px;
		cursor: pointer;
		font-size: 13px;
		text-decoration: none;
	}

	.action-link:hover {
		text-decoration: underline;
	}

	.empty {
		padding: 40px;
		text-align: center;
		color: #777;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/../main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/../main/sidebar.php'; ?>

		<main class="studio-page">

			<div class="studio-layout">

				<h1 class="studio-title">Channel content</h1>

				<div class="studio-section">

					<div class="section-header">
						<h2>Videos</h2>

						<button
							class="upload-btn"
							onclick="Redirect('/Studio/upload.php')"
						>
							Upload
						</button>
					</div>

					<?php if ($videos->num_rows == 0) { ?>

						<div class="empty">
							No videos uploaded yet.
						</div>

					<?php } else { ?>

						<table class="video-table">

							<thead>
								<tr>
									<th>Video</th>
									<th>Views</th>
									<th>Comments</th>
									<th>Date</th>
									<th>Actions</th>
								</tr>
							</thead>

							<tbody>

								<?php while ($video = $videos->fetch_assoc()) { ?>

									<?php
									$commentCount = SqlQuery("
										SELECT COUNT(*) AS total
										FROM comments
										WHERE videoid = '{$video['videoid']}'
									")->fetch_assoc()['total'];
									?>

									<tr>
										<td>
											<div class="video-info">
												<div class="video-thumb">
													<img src="/api/video/thumbnail.php?id=<?= $video['videoid']; ?>">
												</div>

												<div>
													<div class="video-name">
														<?= htmlspecialchars($video['name']); ?>
													</div>

													<div class="video-desc">
														<?= htmlspecialchars($video['description'] ?? "No description"); ?>
													</div>
												</div>
											</div>
										</td>

										<td><?= FormatNumber($video['views']); ?></td>

										<td><?= FormatNumber($commentCount); ?></td>

										<td><?= FormatDateAgo($video['published_at']); ?></td>

										<td>
											<a
												class="action-link"
												href="/watch.php?id=<?= $video['videoid']; ?>"
											>
												View
											</a>

											<a
												class="action-link"
												href="/studio/edit.php?id=<?= $video['videoid']; ?>"
											>
												Edit
											</a>
										</td>
									</tr>

								<?php } ?>

							</tbody>

						</table>

					<?php } ?>

				</div>

			</div>

		</main>

	</div>

</body>
</html>