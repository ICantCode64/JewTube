<?php
include __DIR__ . '/../core/main.php';

$userId = $_SESSION['userid'] ?? "";

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$user = SqlQuery("
	SELECT *
	FROM users
	WHERE userid = '$userId'
	LIMIT 1
")->fetch_assoc();

$totalVideos = SqlQuery("
	SELECT COUNT(*) AS total
	FROM videos
	WHERE authorid = '$userId'
")->fetch_assoc()['total'];

$totalViews = SqlQuery("
	SELECT SUM(views) AS total
	FROM videos
	WHERE authorid = '$userId'
")->fetch_assoc()['total'] ?? 0;

$latestVideos = SqlQuery("
	SELECT *
	FROM videos
	WHERE authorid = '$userId'
	ORDER BY published_at DESC
	LIMIT 5
");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Studio - <?= $sitename; ?></title>

	<?php include __DIR__ . '/../main/global.php'; ?>

	<style>
	.studio-page {
		padding: 24px;
		width: 100%;
		background: #f9f9f9;
	}

	.studio-layout {
		max-width: 1100px;
		margin: 0 auto;
	}

	.studio-title {
		font-size: 26px;
		font-weight: normal;
		margin: 0 0 22px;
		color: #111;
	}

	.stats-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 16px;
		margin-bottom: 24px;
	}

	.stat-card {
		background: white;
		border: 1px solid #ddd;
		padding: 18px;
	}

	.stat-label {
		font-size: 13px;
		color: #666;
		margin-bottom: 8px;
	}

	.stat-value {
		font-size: 28px;
		color: #111;
	}

	.studio-section {
		background: white;
		border: 1px solid #ddd;
		margin-bottom: 24px;
	}

	.section-header {
		padding: 14px 16px;
		border-bottom: 1px solid #ddd;
		font-size: 18px;
		color: #111;
	}

	.video-row {
		display: flex;
		gap: 14px;
		padding: 14px 16px;
		border-bottom: 1px solid #eee;
		cursor: pointer;
	}

	.video-row:last-child {
		border-bottom: none;
	}

	.video-thumb {
		width: 160px;
		height: 90px;
		background: #111;
		position: relative;
		flex-shrink: 0;
		overflow: hidden;
	}

	.video-thumb img {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
	}

	.video-info {
		flex: 1;
	}

	.video-info h3 {
		margin: 0 0 8px;
		font-size: 16px;
		font-weight: normal;
		color: #111;
	}

	.video-info p {
		margin: 0;
		font-size: 13px;
		color: #666;
		line-height: 1.5;
	}

	.quick-actions {
		display: flex;
		gap: 10px;
		padding: 16px;
	}

	.action-btn {
		background: #f1f1f1;
		border: 1px solid #ccc;
		color: #111;
		padding: 9px 14px;
		font-size: 13px;
		cursor: pointer;
	}

	.upload-btn {
		background: #cc0000;
		border-color: #cc0000;
		color: white;
	}

	.empty {
		padding: 30px;
		color: #777;
		text-align: center;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/../main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/../main/sidebar.php'; ?>

		<main class="studio-page">

			<div class="studio-layout">

				<h1 class="studio-title">
					Channel dashboard
				</h1>

				<div class="stats-grid">

					<div class="stat-card">
						<div class="stat-label">Subscribers</div>
						<div class="stat-value">
							<?= FormatNumber($user['subscribers']); ?>
						</div>
					</div>

					<div class="stat-card">
						<div class="stat-label">Total views</div>
						<div class="stat-value">
							<?= FormatNumber($totalViews); ?>
						</div>
					</div>

					<div class="stat-card">
						<div class="stat-label">Videos</div>
						<div class="stat-value">
							<?= FormatNumber($totalVideos); ?>
						</div>
					</div>

				</div>

				<div class="studio-section">
					<div class="section-header">Quick actions</div>

					<div class="quick-actions">
						<button class="action-btn upload-btn" onclick="Redirect('/Studio/upload.php')">
							Upload video
						</button>

						<button class="action-btn" onclick="Redirect('/Channel.php?id=<?= $userId; ?>')">
							View channel
						</button>

						<button class="action-btn" onclick="Redirect('/Studio/videos.php')">
							Manage videos
						</button>
					</div>
				</div>

				<div class="studio-section">

					<div class="section-header">Latest videos</div>

					<?php if ($totalVideos == 0) { ?>

						<div class="empty">
							No videos uploaded yet.
						</div>

					<?php } else { ?>

						<?php while ($video = $latestVideos->fetch_assoc()) { ?>

							<div
								class="video-row"
								onclick="Redirect('/watch.php?id=<?= $video['videoid']; ?>')"
							>
								<div class="video-thumb">
									<img src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>">
								</div>

								<div class="video-info">
									<h3>
										<?= htmlspecialchars($video['name']); ?>
									</h3>

									<p>
										<?= FormatNumber($video['views']); ?> views<br>
										Uploaded <?= FormatDateAgo($video['published_at']); ?>
									</p>
								</div>
							</div>

						<?php } ?>

					<?php } ?>

				</div>

			</div>

		</main>

	</div>

</body>
</html>