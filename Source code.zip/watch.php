<?php
include __DIR__ . '/core/main.php';

$id = isset($_GET['id']) ? SafeVar($_GET['id']) : "";

if ($id == "") {
	die("No video selected.");
}

$video = SqlQuery("
	SELECT *
	FROM videos
	WHERE videoid = '$id'
	LIMIT 1
")->fetch_assoc();

if (!$video) {
	die("Video not found.");
}

$creator = SqlQuery("
	SELECT *
	FROM users
	WHERE userid = '{$video['authorid']}'
	LIMIT 1
")->fetch_assoc();

if (isset($_POST['comment']) && trim($_POST['comment']) != "") {

	$comment = SafeVar($_POST['comment']);
	$userId = $_SESSION['userid'] ?? "";

	$parentId = isset($_POST['parentid'])
		? (int) $_POST['parentid']
		: 0;

	if ($userId != "") {

		SqlQuery("
			INSERT INTO comments (videoid, userid, comment, parentid)
			VALUES (
				'$id',
				'$userId',
				'$comment',
				" . ($parentId > 0 ? $parentId : "NULL") . "
			)
		");

		header("Location: /watch.php?id=$id");
		exit;
	}
}

SqlQuery("
	UPDATE videos
	SET views = views + 1
	WHERE videoid = '$id'
");

if ($loggedin) {
	$userid = $_SESSION["userid"];
	SqlQuery("
		INSERT INTO history (userid, videoid)
		VALUES (
			'$userid',
			'$id'
		)
		ON DUPLICATE KEY UPDATE
			videoid = '$id'
	");
}

$likes = SqlQuery("
	SELECT likes FROM videos
	WHERE videoid = '$id'
	LIMIT 1
")->fetch_assoc()['likes'];

$dislikes = SqlQuery("
	SELECT dislikes FROM videos
	WHERE videoid = '$id'
	LIMIT 1
")->fetch_assoc()['dislikes'];
?>
<!DOCTYPE html>
<html>
<head>
	<title><?= htmlspecialchars($video['name']); ?> - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<link href="https://cdn.jsdelivr.net/npm/video.js@8.23.7/dist/video-js.min.css" rel="stylesheet">
	<link href="/static/videojs-yt-style.css?v=<?= time() ?>" rel="stylesheet">

	<script src="https://cdn.jsdelivr.net/npm/video.js@8.23.7/dist/video.min.js"></script>
	<script src="/static/videojs-yt-style.min.js"></script>

	<style>
	.watch-page {
		padding: 24px;
		width: 100%;
	}

	.watch-layout {
		max-width: 1000px;
		margin: 0 auto;
	}

	.video-title {
		font-size: 20px;
		font-weight: normal;
		margin: 14px 0 10px;
		color: #111;
	}

	.video-meta-row {
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-bottom: 1px solid #ddd;
		padding-bottom: 12px;
		margin-bottom: 12px;
	}

	.video-meta {
		color: #666;
		font-size: 14px;
		margin: 0;
	}

	.video-actions {
		display: flex;
		gap: 8px;
	}

	.video-action {
		background: #f1f1f1;
		border: 1px solid #ccc;
		padding: 7px 12px;
		font-size: 13px;
		cursor: pointer;
	}

	.channel-row {
		display: flex;
		align-items: center;
		gap: 12px;
		padding: 12px 0;
		cursor: pointer;
	}

	.channel-avatar {
		width: 48px;
		height: 48px;
		border-radius: 50%;
		object-fit: cover;
	}

	.channel-main {
		flex: 1;
	}

	.channel-name {
		font-size: 15px;
		color: #111;
		margin-bottom: 3px;
	}

	.subscribe-btn {
		background: #cc0000;
		color: white;
		border: none;
		padding: 9px 14px;
		font-size: 13px;
		cursor: pointer;
	}

	.description {
		margin-left: 60px;
		margin-top: 4px;
		padding: 0 0 16px;
		color: #333;
		font-size: 14px;
		line-height: 1.5;
		border-bottom: 1px solid #ddd;
	}

	.comments {
		margin-top: 32px;
	}

	.comments-title {
		font-size: 16px;
		font-weight: 500;
		margin-bottom: 24px;
		color: #0f0f0f;
	}

	.comment-form {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		margin-bottom: 32px;
	}

	.comment-form-avatar {
		width: 40px;
		height: 40px;
		border-radius: 50%;
		flex-shrink: 0;
		object-fit: cover;
	}

	.comment-form-main {
		flex: 1;
	}

	.comment-box {
		width: 100%;
		border: none;
		border-bottom: 1px solid #d3d3d3;
		padding: 6px 0 10px;
		font-size: 14px;
		background: transparent;
		outline: none;
		resize: none;
		font-family: inherit;
		min-height: 20px;
	}

	.comment-box:focus {
		border-bottom: 2px solid #0f0f0f;
	}

	.comment-actions {
		display: flex;
		justify-content: flex-end;
		margin-top: 10px;
	}

	.comment-submit {
		background: #065fd4;
		color: white;
		border: 1px solid #167ac6;
		border-radius: 0;
		padding: 7px 14px;
		font-size: 12px;
		font-weight: bold;
		cursor: pointer;
		text-transform: uppercase;
	}

	.comment-submit:hover {
		background: #167ac6;
	}

	.comment {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		margin-bottom: 28px;
	}

	.comment-avatar {
		width: 40px;
		height: 40px;
		border-radius: 50%;
		object-fit: cover;
		flex-shrink: 0;
	}

	.comment-main {
		flex: 1;
	}

	.comment-header {
		display: flex;
		align-items: center;
		gap: 6px;
		margin-bottom: 4px;
	}

	.comment-author {
		font-size: 13px;
		font-weight: 500;
		color: #0f0f0f;
	}

	.comment-date {
		font-size: 12px;
		color: #606060;
	}

	.comment-text {
		font-size: 14px;
		line-height: 1.45;
		color: #0f0f0f;
		white-space: pre-wrap;
		word-break: break-word;
	}

	.comment-tools {
		display: flex;
		align-items: center;
		gap: 18px;
		margin-top: 8px;
		color: #606060;
		font-size: 12px;
	}

	.comment-tool {
		cursor: pointer;
		user-select: none;
	}

	.comment-tool:hover {
		color: #0f0f0f;
	}

	.reply-form {
		margin-top: 14px;
		margin-bottom: 10px;
	}

	.reply-comment {
		margin-left: 0px;
		margin-top: 14px;
		margin-bottom: 16px;
	}

	.video-js {
		width: 100%;
		aspect-ratio: 16 / 9;
		background: black;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="watch-page">

			<div class="watch-layout">

				<video
					id="player"
					class="video-js vjs-default-skin vjs-big-play-centered"
					controls
					preload="auto"
				>
					<source
						src="/uploads/videos/<?= htmlspecialchars($video['filename']); ?>"
						type="video/mp4"
					>
				</video>

				<h1 class="video-title">
					<?= htmlspecialchars($video['name']); ?>
				</h1>

				<div class="video-meta-row">

					<div class="video-meta">
						<?= FormatNumber($video['views'] + 1); ?> views ·
						<?= FormatDateAgo($video['published_at']); ?>
					</div>

					<div class="video-actions">
						<button class="video-action" onclick="Redirect('/api/videos/rate.php?id=<?= $id ?>&rate=like')">Like (<?= FormatNumber($likes); ?>)</button>
						<button class="video-action" onclick="Redirect('/api/videos/rate.php?id=<?= $id ?>&rate=dislike')">Dislike (<?= FormatNumber($dislikes); ?>)</button>
						<button class="video-action">Share</button>
						<button class="video-action" onclick="Redirect('/AddToPlaylist.php?video=<?= $id ?>')">Add to playlist</button>
					</div>

				</div>

				<?php if ($creator) { ?>

					<div
						class="channel-row"
						onclick="Redirect('/Channel.php?id=<?= $creator['userid']; ?>')"
					>

						<img
							class="channel-avatar"
							src="/api/user/thumbnail.php?id=<?= $creator['userid']; ?>"
						>

						<div class="channel-main">

							<div class="channel-name">
								<?= htmlspecialchars($creator['username']); ?>
							</div>

							<div class="video-meta">
								<?= FormatNumber($creator['subscribers']); ?> subscribers
							</div>

						</div>

						<button class="subscribe-btn">
							Subscribe
						</button>

					</div>

				<?php } ?>

				<div class="description">
					<?= nl2br(htmlspecialchars($video['description'] ?? "No description.")); ?>
				</div>

				<div class="comments">

					<?php
					$commentCount = SqlQuery("
						SELECT COUNT(*) AS total
						FROM comments
						WHERE videoid = '$id'
					")->fetch_assoc()['total'];
					?>

					<h2 class="comments-title">
						<?= FormatNumber($commentCount); ?> comments
					</h2>

					<?php if (isset($_SESSION['userid'])) { ?>

						<form class="comment-form" method="POST">

							<img
								class="comment-form-avatar"
								src="/api/user/thumbnail.php?id=<?= $_SESSION['userid']; ?>"
							>

							<div class="comment-form-main">

								<textarea
									class="comment-box"
									name="comment"
									placeholder="Add a comment..."
									required
								></textarea>

								<div class="comment-actions">
									<button class="comment-submit" type="submit">
										Comment
									</button>
								</div>

							</div>

						</form>

					<?php } else { ?>

						<p class="video-meta">Log in to comment.</p>
                        <br><br>

					<?php } ?>

					<?php
					$comments = SqlQuery("
						SELECT comments.*, users.username
						FROM comments
						LEFT JOIN users ON users.userid = comments.userid
						WHERE comments.videoid = '$id'
						AND comments.parentid IS NULL
						ORDER BY comments.created_at DESC
					");

					while ($comment = $comments->fetch_assoc()) {
					?>

						<div class="comment">

							<img
								class="comment-avatar"
								src="/api/user/thumbnail.php?id=<?= $comment['userid']; ?>"
							>

							<div class="comment-main">

								<div class="comment-header">

									<div class="comment-author">
										<?= htmlspecialchars($comment['username'] ?? "Unknown"); ?>
									</div>

									<div class="comment-date">
										<?= FormatDateAgo($comment['created_at']); ?>
									</div>

								</div>

								<div class="comment-text"><?= nl2br(htmlspecialchars($comment['comment'])); ?></div>

								<div class="comment-tools">
									<div class="comment-tool">Like</div>

									<?php if (isset($_SESSION['userid'])) { ?>
										<div
											class="comment-tool"
											onclick="ToggleReply(<?= $comment['id']; ?>)"
										>
											Reply
										</div>
									<?php } ?>
								</div>

								<?php if (isset($_SESSION['userid'])) { ?>

									<div
										class="reply-form"
										id="reply-<?= $comment['id']; ?>"
										style="display:none;"
									>

										<form method="POST">

											<input
												type="hidden"
												name="parentid"
												value="<?= $comment['id']; ?>"
											>

											<textarea
												class="comment-box"
												name="comment"
												placeholder="Reply..."
												required
											></textarea>

											<div class="comment-actions">
												<button class="comment-submit" type="submit">
													Reply
												</button>
											</div>

										</form>

									</div>

								<?php } ?>

								<?php
								$replies = SqlQuery("
									SELECT comments.*, users.username
									FROM comments
									LEFT JOIN users ON users.userid = comments.userid
									WHERE comments.parentid = '{$comment['id']}'
									ORDER BY comments.created_at ASC
								");

								while ($reply = $replies->fetch_assoc()) {
								?>

									<div class="comment reply-comment">

										<img
											class="comment-avatar"
											src="/api/user/thumbnail.php?id=<?= $reply['userid']; ?>"
										>

										<div class="comment-main">

											<div class="comment-header">

												<div class="comment-author">
													<?= htmlspecialchars($reply['username'] ?? "Unknown"); ?>
												</div>

												<div class="comment-date">
													<?= FormatDateAgo($reply['created_at']); ?>
												</div>

											</div>

											<div class="comment-text"><?= nl2br(htmlspecialchars($reply['comment'])); ?></div>

										</div>

									</div>

								<?php } ?>

							</div>

						</div>

					<?php } ?>

				</div>

			</div>

		</main>

	</div>

	<script>
		const player = videojs('player', {
			fluid: true,
			playbackRates: [0.25, 0.5, 1, 1.5, 2]
		});

		player.ready(function () {
			player.ytStyle();
		});

		function ToggleReply(id) {
			const el = document.getElementById('reply-' + id);
			el.style.display = el.style.display === 'none' ? 'block' : 'none';
		}

		document.addEventListener('keydown', (e) => {
			const tag = document.activeElement?.tagName?.toLowerCase();

			if (
				tag === 'input' ||
				tag === 'textarea' ||
				document.activeElement?.isContentEditable
			) {
				return;
			}

			const key = e.key.toLowerCase();

			switch (key) {
				case 'k':
				case ' ':
					e.preventDefault();
					e.stopPropagation();

					player.paused() ? player.play() : player.pause();
					break;

				case 'f':
					e.preventDefault();
					player.requestFullscreen();
					break;

				case 'm':
					e.preventDefault();
					player.muted(!player.muted());
					break;

				case 'arrowright':
					e.preventDefault();
					player.currentTime(player.currentTime() + 5);
					break;

				case 'arrowleft':
					e.preventDefault();
					player.currentTime(Math.max(0, player.currentTime() - 5));
					break;

				case 'arrowup':
					e.preventDefault();
					player.volume(Math.min(1, player.volume() + 0.1));
					break;

				case 'arrowdown':
					e.preventDefault();
					player.volume(Math.max(0, player.volume() - 0.1));
					break;
			}
		}, true);
	</script>

</body>
</html>