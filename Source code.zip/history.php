<?php
include __DIR__ . '/core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$userid = $_SESSION["userid"];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
	$page = 1;
}

$perpage = 10;
$offset = ($page - 1) * $perpage;

$totalhistory = SqlQuery("
	SELECT COUNT(*) AS total
	FROM history
	WHERE userid = '$userid'
")->fetch_assoc()['total'];

$totalpages = ceil($totalhistory / $perpage);

$history = SqlQuery("
	SELECT 
		videos.*,
		history.created_at AS watched_at,
		users.username AS creator,
        history.id AS historyid
	FROM history
	INNER JOIN videos ON history.videoid = videos.videoid
	INNER JOIN users ON videos.authorid = users.userid
	WHERE history.userid = '$userid'
	ORDER BY history.created_at DESC
	LIMIT $offset, $perpage
");
?>
<!DOCTYPE html>
<html>
<head>
	<title>History - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.history-page {
		padding: 24px;
		width: 100%;
	}

	.page-title {
		font-size: 28px;
		font-weight: normal;
		margin: 0 0 20px;
	}

	.history-list {
		background: white;
		border: 1px solid #ddd;
		padding: 18px;
	}

	.history-video {
		display: flex;
		gap: 14px;
		padding: 14px 0;
		border-bottom: 1px solid #eee;
		cursor: pointer;
	}

	.history-video:last-child {
		border-bottom: none;
	}

	.history-video .thumb {
		width: 210px;
		height: 118px;
		flex-shrink: 0;
		position: relative;
		background: #ddd;
		overflow: hidden;
	}

	.history-info h2 {
		margin: 0 0 6px;
		font-size: 18px;
		font-weight: normal;
		color: #111;
	}

	.history-info p {
		margin: 0;
		color: #666;
		font-size: 14px;
		line-height: 1.5;
	}

	.no-results {
		background: white;
		border: 1px solid #ddd;
		padding: 30px;
		text-align: center;
		color: #777;
	}

	.thumb-image {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
	}

	.duration {
		position: absolute;
		right: 6px;
		bottom: 6px;
		background: rgba(0,0,0,0.85);
		color: white;
		font-size: 12px;
		padding: 2px 5px;
	}

	.pagination {
		display: flex;
		gap: 8px;
		margin-top: 24px;
		flex-wrap: wrap;
	}

	.pagination a {
		background: white;
		border: 1px solid #ddd;
		padding: 8px 14px;
		text-decoration: none;
		color: #333;
		font-size: 14px;
	}

	.pagination a:hover {
		background: #f5f5f5;
	}

	.pagination a.active {
		background: #cc0000;
		border-color: #cc0000;
		color: white;
	}

    .history-actions {
        margin-left: auto;
        display: flex;
        align-items: center;
    }

    .remove-history {
        background: #f8f8f8;
        border: 1px solid #ccc;
        padding: 8px 14px;
        font-size: 13px;
        color: #555;
        cursor: pointer;
    }

    .remove-history:hover {
        background: #eee;
    }

    .history-topbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .clear-history {
        background: #f8f8f8;
        border: 1px solid #ccc;
        padding: 8px 14px;
        font-size: 13px;
        color: #555;
        cursor: pointer;
    }

    .clear-history:hover {
        background: #eee;
    }
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="history-page">

			<div class="history-topbar">

                <h1 class="page-title">
                    History
                </h1>

                <button
                    class="clear-history"
                    onclick="Redirect('/api/history/clear.php')"
                >
                    Clear History
                </button>

            </div>

			<?php if ($history->num_rows == 0) { ?>

				<div class="no-results">
					<p>No watch history yet.</p>
				</div>

			<?php } else { ?>

				<div class="history-list">

					<?php while ($video = $history->fetch_assoc()) { ?>

						<div
							class="history-video"
							onclick="Redirect('/watch.php?id=<?= $video['videoid']; ?>')"
						>

							<div class="thumb">

								<img
									class="thumb-image"
									src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>"
								>

								<div class="duration">
									<?= FormatDuration($video['duration']) ?>
								</div>

							</div>

							<div class="history-info">

								<h2>
									<?= htmlspecialchars($video['name']); ?>
								</h2>

								<p>
									<?= htmlspecialchars($video['creator']); ?><br>
									<?= FormatNumber($video['views']); ?> views ·
									watched <?= FormatDateAgo($video['watched_at']); ?>
								</p>

							</div>

                            <div class="history-actions">

                                <button
                                    class="remove-history"
                                    onclick="event.stopPropagation(); Redirect('/api/history/remove.php?id=<?= $video['historyid']; ?>')"
                                >
                                    Remove
                                </button>

                            </div>

						</div>

					<?php } ?>

				</div>

				<?php if ($totalpages > 1) { ?>

					<div class="pagination">

						<?php if ($page > 1) { ?>
							<a href="/History.php?page=<?= $page - 1; ?>">
								Previous
							</a>
						<?php } ?>

						<?php for ($i = 1; $i <= $totalpages; $i++) { ?>

							<a
								class="<?= $i == $page ? 'active' : ''; ?>"
								href="/History.php?page=<?= $i; ?>"
							>
								<?= $i; ?>
							</a>

						<?php } ?>

						<?php if ($page < $totalpages) { ?>
							<a href="/History.php?page=<?= $page + 1; ?>">
								Next
							</a>
						<?php } ?>

					</div>

				<?php } ?>

			<?php } ?>

		</main>

	</div>

</body>
</html>