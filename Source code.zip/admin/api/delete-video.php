<?php
include __DIR__ . "/../admin_default.php";

$id = $_GET['id'];
$id = SafeVar($id);

SqlQuery("
    DELETE FROM videos
    WHERE videoid = '$id'
");

header("Location: /admin/videos.php");
?>