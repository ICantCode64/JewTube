<?php
include __DIR__ . "/../admin_default.php";

$id = $_GET['id'];
$id = SafeVar($id);

SqlQuery("
    DELETE FROM comments
    WHERE id = '$id'
");

header("Location: /admin/comments.php");
?>