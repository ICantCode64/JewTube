<?php
include __DIR__ . '/admin_default.php';

$stats = [
	"users" => SqlQuery("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'],
	"videos" => SqlQuery("SELECT COUNT(*) AS total FROM videos")->fetch_assoc()['total'],
	"comments" => SqlQuery("SELECT COUNT(*) AS total FROM comments")->fetch_assoc()['total']
];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin - <?= $sitename; ?></title>
	<?php include __DIR__ . '/../main/global.php'; ?>

	<style>
	.admin-page {
		padding: 24px;
		width: 100%;
		background: #f9f9f9;
	}

	.admin-layout {
		max-width: 900px;
		margin: 0 auto;
	}

	.admin-title {
		font-size: 26px;
		font-weight: normal;
		margin-bottom: 22px;
		color: #111;
	}

	.stats-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 16px;
		margin-bottom: 22px;
	}

	.stat-card {
		background: white;
		border: 1px solid #ddd;
		padding: 20px;
	}

	.stat-number {
		font-size: 30px;
		color: #111;
		margin-bottom: 6px;
	}

	.stat-label {
		font-size: 13px;
		color: #666;
	}

	.admin-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 16px;
	}

	.admin-card {
		background: white;
		border: 1px solid #ddd;
		padding: 24px;
		text-decoration: none;
		color: #111;
	}

	.admin-card:hover {
		border-color: #999;
	}

	.card-title {
		font-size: 20px;
		margin-bottom: 8px;
	}

	.card-desc {
		font-size: 13px;
		color: #666;
	}
	</style>
</head>

<body>
	<?php include __DIR__ . '/../main/header.php'; ?>

	<div class="layout">
		<?php include __DIR__ . '/../main/sidebar.php'; ?>

		<main class="admin-page">
			<div class="admin-layout">

				<h1 class="admin-title">Admin panel</h1>

				<div class="stats-grid">
					<div class="stat-card">
						<div class="stat-number"><?= FormatNumber($stats['users']); ?></div>
						<div class="stat-label">Total users</div>
					</div>

					<div class="stat-card">
						<div class="stat-number"><?= FormatNumber($stats['videos']); ?></div>
						<div class="stat-label">Total videos</div>
					</div>

					<div class="stat-card">
						<div class="stat-number"><?= FormatNumber($stats['comments']); ?></div>
						<div class="stat-label">Total comments</div>
					</div>
				</div>

				<div class="admin-grid">

					<a class="admin-card" href="/admin/users.php">
						<div class="card-title">Users</div>
						<div class="card-desc">Manage site users.</div>
					</a>

					<a class="admin-card" href="/admin/videos.php">
						<div class="card-title">Videos</div>
						<div class="card-desc">Manage uploaded videos.</div>
					</a>

					<a class="admin-card" href="/admin/comments.php">
						<div class="card-title">Comments</div>
						<div class="card-desc">Manage comments.</div>
					</a>

				</div>

			</div>
		</main>
	</div>
</body>
</html>