<?php
include __DIR__ . '/admin_default.php';

if (isset($_GET['ban'])) {
	$banId = (int) $_GET['ban'];

	SqlQuery("
		UPDATE users
		SET banned = 1
		WHERE userid = '$banId'
	");

	header("Location: /admin/users.php");
	exit;
}

if (isset($_GET['unban'])) {
	$banId = (int) $_GET['unban'];

	SqlQuery("
		UPDATE users
		SET banned = 0
		WHERE userid = '$banId'
	");

	header("Location: /admin/users.php");
	exit;
}

$users = SqlQuery("SELECT * FROM users ORDER BY userid DESC");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Users - <?= $sitename; ?> Admin</title>
	<?php include __DIR__ . '/../main/global.php'; ?>

	<style>
	.admin-page { padding: 24px; width: 100%; background: #f9f9f9; }
	.admin-layout { max-width: 1100px; margin: 0 auto; }
	.admin-title { font-size: 26px; font-weight: normal; margin-bottom: 22px; color: #111; }
	.admin-section { background: white; border: 1px solid #ddd; }
	.admin-table { width: 100%; border-collapse: collapse; }
	.admin-table th { text-align: left; font-weight: normal; color: #666; font-size: 13px; padding: 10px 14px; border-bottom: 1px solid #ddd; }
	.admin-table td { padding: 12px 14px; border-bottom: 1px solid #eee; font-size: 13px; color: #333; }
	.action-link { color: #065fd4; margin-right: 10px; text-decoration: none; }
	.action-link:hover { text-decoration: underline; }
	.danger-link { color: #cc0000; }
	.back-link { display: inline-block; margin-bottom: 14px; color: #065fd4; text-decoration: none; }
	.status-active { color: #178a00; }
	.status-banned { color: #cc0000; }
	</style>
</head>

<body>
<?php include __DIR__ . '/../main/header.php'; ?>

<div class="layout">
<?php include __DIR__ . '/../main/sidebar.php'; ?>

<main class="admin-page">
	<div class="admin-layout">

		<a class="back-link" href="/admin/index.php">Back to admin</a>

		<h1 class="admin-title">Users</h1>

		<div class="admin-section">
			<table class="admin-table">
				<thead>
					<tr>
						<th>Username</th>
						<th>Email</th>
						<th>Subscribers</th>
						<th>Role</th>
						<th>Status</th>
						<th>Created</th>
						<th>Actions</th>
					</tr>
				</thead>

				<tbody>
					<?php while ($row = $users->fetch_assoc()) { ?>
						<tr>
							<td><?= htmlspecialchars($row['username']); ?></td>

							<td><?= htmlspecialchars($row['email']); ?></td>

							<td><?= FormatNumber($row['subscribers']); ?></td>

							<td><?= htmlspecialchars($row['role']); ?></td>

							<td>
								<?php if (($row['banned'] ?? 0) == 1) { ?>
									<span class="status-banned">Banned</span>
								<?php } else { ?>
									<span class="status-active">Active</span>
								<?php } ?>
							</td>

							<td><?= FormatDateAgo($row['created_at']); ?></td>

							<td>
								<?php if (($row['banned'] ?? 0) == 1) { ?>

									<a
										class="action-link"
										href="/admin/users.php?unban=<?= $row['userid']; ?>"
										onclick="return confirm('Unban this user?')"
									>
										Unban
									</a>

								<?php } else { ?>

									<a
										class="action-link danger-link"
										href="/admin/users.php?ban=<?= $row['userid']; ?>"
										onclick="return confirm('Ban this user?')"
									>
										Ban
									</a>

								<?php } ?>
							</td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>

	</div>
</main>
</div>
</body>
</html>