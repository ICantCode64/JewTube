<?php
include __DIR__ . '/admin_default.php';

$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;

$perPage = 15;
$offset = ($page - 1) * $perPage;

$totalVideos = SqlQuery("
	SELECT COUNT(*) AS total
	FROM videos
")->fetch_assoc()['total'];

$totalPages = max(1, ceil($totalVideos / $perPage));

$videos = SqlQuery("
	SELECT videos.*, users.username
	FROM videos
	LEFT JOIN users ON users.userid = videos.authorid
	ORDER BY videos.published_at DESC
	LIMIT $perPage OFFSET $offset
");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Videos - <?= $sitename; ?> Admin</title>
	<?php include __DIR__ . '/../main/global.php'; ?>

	<style>
	.admin-page { padding: 24px; width: 100%; background: #f9f9f9; }
	.admin-layout { max-width: 1100px; margin: 0 auto; }
	.admin-title { font-size: 26px; font-weight: normal; margin-bottom: 22px; color: #111; }
	.admin-section { background: white; border: 1px solid #ddd; }
	.admin-table { width: 100%; border-collapse: collapse; }

	.admin-table th {
		text-align: left;
		font-weight: normal;
		color: #666;
		font-size: 13px;
		padding: 10px 14px;
		border-bottom: 1px solid #ddd;
	}

	.admin-table td {
		padding: 12px 14px;
		border-bottom: 1px solid #eee;
		font-size: 13px;
		color: #333;
	}

	.action-link {
		color: #065fd4;
		margin-right: 10px;
		text-decoration: none;
	}

	.action-link:hover {
		text-decoration: underline;
	}

	.back-link {
		display: inline-block;
		margin-bottom: 14px;
		color: #065fd4;
		text-decoration: none;
	}

	.pagination {
		margin-top: 18px;
		display: flex;
		gap: 14px;
		align-items: center;
		justify-content: center;
		font-size: 14px;
	}

	.pagination a {
		color: #065fd4;
		text-decoration: none;
	}

	.pagination a:hover {
		text-decoration: underline;
	}

	.pagination span {
		color: #666;
	}
	</style>
</head>

<body>

<?php include __DIR__ . '/../main/header.php'; ?>

<div class="layout">

<?php include __DIR__ . '/../main/sidebar.php'; ?>

<main class="admin-page">

	<div class="admin-layout">

		<a class="back-link" href="/admin/index.php">
			Back to admin
		</a>

		<h1 class="admin-title">
			Videos
		</h1>

		<div class="admin-section">

			<table class="admin-table">

				<thead>
					<tr>
						<th>Title</th>
						<th>Uploader</th>
						<th>Views</th>
						<th>Date</th>
						<th>Actions</th>
					</tr>
				</thead>

				<tbody>

					<?php while ($video = $videos->fetch_assoc()) { ?>

						<tr>

							<td>
								<?= htmlspecialchars($video['name']); ?>
							</td>

							<td>
								<?= htmlspecialchars($video['username'] ?? "Unknown"); ?>
							</td>

							<td>
								<?= FormatNumber($video['views']); ?>
							</td>

							<td>
								<?= FormatDateAgo($video['published_at']); ?>
							</td>

							<td>
								<a
									class="action-link"
									href="/watch.php?id=<?= $video['videoid']; ?>"
								>
									View
								</a>

								<a
									class="action-link"
									href="/admin/api/delete-video.php?id=<?= $video['videoid']; ?>"
									onclick="return confirm('Delete this video?')"
								>
									Delete
								</a>
							</td>

						</tr>

					<?php } ?>

				</tbody>

			</table>

		</div>

		<?php if ($totalPages > 1) { ?>

			<div class="pagination">

				<?php if ($page > 1) { ?>

					<a href="/admin/videos.php?page=<?= $page - 1; ?>">
						Previous
					</a>

				<?php } ?>

				<span>
					Page <?= $page; ?> of <?= $totalPages; ?>
				</span>

				<?php if ($page < $totalPages) { ?>

					<a href="/admin/videos.php?page=<?= $page + 1; ?>">
						Next
					</a>

				<?php } ?>

			</div>

		<?php } ?>

	</div>

</main>

</div>

</body>
</html>