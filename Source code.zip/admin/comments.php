<?php
include __DIR__ . '/admin_default.php';

$comments = SqlQuery("
	SELECT comments.*, users.username, videos.name AS video_title
	FROM comments
	LEFT JOIN users ON users.userid = comments.userid
	LEFT JOIN videos ON videos.videoid = comments.videoid
	ORDER BY comments.created_at DESC
");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Comments - <?= $sitename; ?> Admin</title>
	<?php include __DIR__ . '/../main/global.php'; ?>

	<style>
	.admin-page { padding: 24px; width: 100%; background: #f9f9f9; }
	.admin-layout { max-width: 1100px; margin: 0 auto; }
	.admin-title { font-size: 26px; font-weight: normal; margin-bottom: 22px; color: #111; }
	.admin-section { background: white; border: 1px solid #ddd; }
	.admin-table { width: 100%; border-collapse: collapse; }
	.admin-table th { text-align: left; font-weight: normal; color: #666; font-size: 13px; padding: 10px 14px; border-bottom: 1px solid #ddd; }
	.admin-table td { padding: 12px 14px; border-bottom: 1px solid #eee; font-size: 13px; color: #333; }
	.action-link { color: #065fd4; margin-right: 10px; text-decoration: none; }
	.action-link:hover { text-decoration: underline; }
	.back-link { display: inline-block; margin-bottom: 14px; color: #065fd4; text-decoration: none; }
	.comment-text { max-width: 420px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	</style>
</head>

<body>
<?php include __DIR__ . '/../main/header.php'; ?>

<div class="layout">
<?php include __DIR__ . '/../main/sidebar.php'; ?>

<main class="admin-page">
	<div class="admin-layout">

		<a class="back-link" href="/admin/index.php">Back to admin</a>

		<h1 class="admin-title">Comments</h1>

		<div class="admin-section">
			<table class="admin-table">
				<thead>
					<tr>
						<th>Comment</th>
						<th>User</th>
						<th>Video</th>
						<th>Date</th>
						<th>Actions</th>
					</tr>
				</thead>

				<tbody>
					<?php while ($comment = $comments->fetch_assoc()) { ?>
						<tr>
							<td>
                                <div class="comment-text">
                                    <?= htmlspecialchars($comment['comment']); ?>
                                </div>
                            </td>

                            <td><?= htmlspecialchars($comment['username'] ?? "Unknown"); ?></td>

                            <td><?= htmlspecialchars($comment['video_title'] ?? "Deleted video"); ?></td>

                            <td><?= FormatDateAgo($comment['created_at']); ?></td>

                            <td>
                                <a class="action-link" href="/watch.php?id=<?= $comment['videoid']; ?>">View</a>
                                <a class="action-link" href="/admin/api/delete-comment.php?id=<?= $comment['id']; ?>" onclick="return confirm('Delete this comment?')">Delete</a>
                            </td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>

	</div>
</main>
</div>
</body>
</html>