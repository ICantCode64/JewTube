<?php
include __DIR__ . '/core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$userid = $_SESSION["userid"];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
	$page = 1;
}

$perpage = 10;
$offset = ($page - 1) * $perpage;

$totalplaylists = SqlQuery("
	SELECT COUNT(*) AS total
	FROM playlists
	WHERE ownerid = '$userid'
")->fetch_assoc()['total'];

$totalpages = ceil($totalplaylists / $perpage);

$playlists = SqlQuery("
	SELECT *
	FROM playlists
	WHERE ownerid = '$userid'
	ORDER BY created_at DESC
	LIMIT $offset, $perpage
");
?>
<!DOCTYPE html>
<html>
<head>
	<title>My Playlists - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.my-playlists-page {
		padding: 24px;
		width: 100%;
	}

	.playlists-topbar {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 20px;
	}

	.page-title {
		font-size: 28px;
		font-weight: normal;
		margin: 0;
	}

	.create-playlist {
		background: #cc0000;
		color: white;
		border: none;
		padding: 9px 14px;
		font-size: 13px;
		text-decoration: none;
		cursor: pointer;
	}

	.create-playlist:hover {
		background: #aa0000;
	}

	.playlists-list {
		background: white;
		border: 1px solid #ddd;
		padding: 18px;
	}

	.playlist-row {
		display: flex;
		gap: 14px;
		padding: 14px 0;
		border-bottom: 1px solid #eee;
		cursor: pointer;
	}

	.playlist-row:last-child {
		border-bottom: none;
	}

	.playlist-thumb {
		width: 210px;
		height: 118px;
		flex-shrink: 0;
		background: #ddd;
		position: relative;
		overflow: hidden;
	}

	.playlist-thumb img {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
	}

	.badge {
		position: absolute;
		right: 6px;
		bottom: 6px;
		background: rgba(0,0,0,0.85);
		color: white;
		font-size: 12px;
		padding: 2px 5px;
	}

	.playlist-info h2 {
		margin: 0 0 6px;
		font-size: 18px;
		font-weight: normal;
		color: #111;
	}

	.playlist-info p {
		margin: 0;
		color: #666;
		font-size: 14px;
		line-height: 1.5;
	}

	.no-results {
		background: white;
		border: 1px solid #ddd;
		padding: 30px;
		text-align: center;
		color: #777;
	}

	.pagination {
		display: flex;
		gap: 8px;
		margin-top: 24px;
		flex-wrap: wrap;
	}

	.pagination a {
		background: white;
		border: 1px solid #ddd;
		padding: 8px 14px;
		text-decoration: none;
		color: #333;
		font-size: 14px;
	}

	.pagination a:hover {
		background: #f5f5f5;
	}

	.pagination a.active {
		background: #cc0000;
		border-color: #cc0000;
		color: white;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="my-playlists-page">

			<div class="playlists-topbar">

				<h1 class="page-title">
					My Playlists
				</h1>

				<a class="create-playlist" href="/CreatePlaylist.php">
					Create Playlist
				</a>

			</div>

			<?php if ($playlists->num_rows == 0) { ?>

				<div class="no-results">
					<p>You have no playlists yet.</p>
				</div>

			<?php } else { ?>

				<div class="playlists-list">

					<?php while ($playlist = $playlists->fetch_assoc()) { ?>

						<?php
						$count = SqlQuery("
							SELECT COUNT(*) AS total
							FROM playlist_videos
							WHERE playlistid = '{$playlist['playlistid']}'
						")->fetch_assoc()['total'];
						?>

						<div
							class="playlist-row"
							onclick="Redirect('/Playlist.php?id=<?= $playlist['playlistid']; ?>')"
						>

							<div class="playlist-thumb">

								<img src="/api/user/thumbnail.php?id=<?= $userid; ?>">

								<div class="badge">
									<?= FormatNumber($count); ?> videos
								</div>

							</div>

							<div class="playlist-info">

								<h2>
									<?= htmlspecialchars($playlist['name']); ?>
								</h2>

								<p>
									<?= FormatNumber($count); ?> videos ·
									created <?= FormatDateAgo($playlist['created_at']); ?>
								</p>

								<?php if (!empty($playlist['description'])) { ?>
									<p>
										<?= htmlspecialchars($playlist['description']); ?>
									</p>
								<?php } ?>

							</div>

						</div>

					<?php } ?>

				</div>

				<?php if ($totalpages > 1) { ?>

					<div class="pagination">

						<?php if ($page > 1) { ?>
							<a href="/MyPlaylists.php?page=<?= $page - 1; ?>">
								Previous
							</a>
						<?php } ?>

						<?php for ($i = 1; $i <= $totalpages; $i++) { ?>
							<a
								class="<?= $i == $page ? 'active' : ''; ?>"
								href="/MyPlaylists.php?page=<?= $i; ?>"
							>
								<?= $i; ?>
							</a>
						<?php } ?>

						<?php if ($page < $totalpages) { ?>
							<a href="/MyPlaylists.php?page=<?= $page + 1; ?>">
								Next
							</a>
						<?php } ?>

					</div>

				<?php } ?>

			<?php } ?>

		</main>

	</div>

</body>
</html>