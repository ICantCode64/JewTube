<?php
include __DIR__ . '/core/main.php';

if ($loggedin) {
    header("Location: /");
    exit;
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST["username"];
    $password = $_POST["password"];

    if (isset($username) && isset($password)) {

        $username = SafeVar($username);
        $password = SafeVar($password);

        $result = SqlQuery("SELECT * FROM users WHERE username = '$username' OR email = '$username'");

        if ($result->num_rows > 0) {

            $row = $result->fetch_assoc();

            if (password_verify($password, $row["password"])) {

                LoginAs($row["userid"]);

                header("Location: /");
                exit;

            } else {

                $error = "Incorrect password.";

            }

        } else {

            $error = "Account not found.";

        }
    }
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title><?= $sitename; ?> - Sign in</title>
		<?php include __DIR__ . '/main/global.php'; ?>
	</head>

	<body>

		<?php include __DIR__ . '/main/header.php'; ?>

		<div class="login-page">

			<div class="login-box">

				<h1>Sign in</h1>

				<p class="login-subtitle">
					to continue to <?= $sitename; ?>
				</p>

				<?php if ($error != "") { ?>
					<div class="error-box">
						<?= $error; ?>
					</div>
				<?php } ?>

				<form action="/login.php" method="post">

					<label>Username or email</label>
					<input type="text" name="username" required>

					<label>Password</label>
					<input type="password" name="password" required>

					<div class="login-options">

						<label class="remember">
							<input type="checkbox" name="remember">
							Remember me
						</label>

						<a href="/forgotpassword.php">
							Forgot password?
						</a>

					</div>

					<button class="login-submit" type="submit">
						Sign in
					</button>

				</form>

				<div class="login-bottom">

					<span>
						New to <?= $sitename; ?>?
					</span>

					<a href="/register.php">
						Create account
					</a>

				</div>

			</div>

		</div>

	</body>
</html>