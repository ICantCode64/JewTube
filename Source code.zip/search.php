<?php
include __DIR__ . '/core/main.php';

$query = isset($_GET['q']) ? SafeVar($_GET['q']) : "";

$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;

$perPage = 10;
$offset = ($page - 1) * $perPage;

$results = [];

$totalResults = 0;
$totalPages = 1;

if ($query != "") {

	$totalVideos = SqlQuery("
		SELECT COUNT(*) AS total
		FROM videos
		WHERE name LIKE '%$query%'
	")->fetch_assoc()['total'];

	$totalPlaylists = SqlQuery("
		SELECT COUNT(*) AS total
		FROM playlists
		WHERE name LIKE '%$query%'
	")->fetch_assoc()['total'];

	$totalResults = $totalVideos + $totalPlaylists;
	$totalPages = max(1, ceil($totalResults / $perPage));

	$searchItems = SqlQuery("
		(
			SELECT
				videoid AS id,
				name,
				description,
				views,
				published_at AS created_at,
				authorid AS ownerid,
				'video' AS type
			FROM videos
			WHERE name LIKE '%$query%'
		)

		UNION ALL

		(
			SELECT
				playlistid AS id,
				name,
				description,
				0 AS views,
				created_at,
				ownerid,
				'playlist' AS type
			FROM playlists
			WHERE name LIKE '%$query%'
		)

		ORDER BY created_at DESC
		LIMIT $perPage OFFSET $offset
	");

	while ($item = $searchItems->fetch_assoc()) {

		$user = SqlQuery("
			SELECT username
			FROM users
			WHERE userid = '{$item['ownerid']}'
		")->fetch_assoc();

		$item['creator'] = $user ? $user['username'] : 'Unknown';

		if ($item['type'] == 'video') {

			$video = SqlQuery("
				SELECT *
				FROM videos
				WHERE videoid = '{$item['id']}'
			")->fetch_assoc();

			$path = $_SERVER['DOCUMENT_ROOT'] . "/uploads/videos/" . $video['filename'];

			$item['filename'] = $video['filename'];
			$item['duration_formatted'] = FormatDuration(
				GetVideoDuration($path, $video['videoid'])
			);

		} else {

			$item['video_count'] = SqlQuery("
				SELECT COUNT(*) AS total
				FROM playlist_videos
				WHERE playlistid = '{$item['id']}'
			")->fetch_assoc()['total'];

		}

		$results[] = $item;
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Search - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.search-page {
		padding: 24px;
		width: 100%;
	}

	.search-title {
		font-size: 24px;
		font-weight: normal;
		margin: 0 0 20px;
	}

	.search-section {
		background: white;
		border: 1px solid #ddd;
		padding: 18px;
	}

	.search-result {
		display: flex;
		gap: 14px;
		padding: 14px 0;
		border-bottom: 1px solid #eee;
		cursor: pointer;
	}

	.search-result:last-child {
		border-bottom: none;
	}

	.result-thumb {
		width: 210px;
		height: 118px;
		background: #111;
		position: relative;
		flex-shrink: 0;
		overflow: hidden;
	}

	.result-thumb img {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
	}

	.duration {
		position: absolute;
		right: 4px;
		bottom: 4px;
		background: rgba(0,0,0,0.85);
		color: white;
		font-size: 11px;
		padding: 2px 4px;
	}

	.search-result-info h3 {
		margin: 0 0 6px;
		font-size: 18px;
		font-weight: normal;
		color: #111;
	}

	.search-result-info p {
		margin: 0;
		color: #666;
		font-size: 14px;
		line-height: 1.5;
	}

	.no-results {
		background: white;
		border: 1px solid #ddd;
		padding: 30px;
		text-align: center;
		color: #777;
	}

	.pagination {
		margin-top: 18px;
		display: flex;
		gap: 14px;
		align-items: center;
		justify-content: center;
		font-size: 14px;
	}

	.pagination a {
		color: #065fd4;
		text-decoration: none;
	}

	.pagination a:hover {
		text-decoration: underline;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="search-page">

			<h1 class="search-title">
				Search results for "<?= htmlspecialchars($query); ?>"
			</h1>

			<?php if ($query == "") { ?>

				<div class="no-results">
					<p>Type something in the search bar.</p>
				</div>

			<?php } elseif (count($results) == 0) { ?>

				<div class="no-results">
					<p>No results found.</p>
				</div>

			<?php } else { ?>

				<div class="search-section">

					<?php foreach ($results as $item) { ?>

						<div
							class="search-result"
							onclick="Redirect('<?= $item['type'] == 'video' ? '/watch.php?id=' . $item['id'] : '/Playlist.php?id=' . $item['id']; ?>')"
						>

							<div class="result-thumb">

								<?php if ($item['type'] == 'video') { ?>

									<img src="/api/videos/thumbnail.php?id=<?= $item['id']; ?>">

									<div class="duration">
										<?= $item['duration_formatted']; ?>
									</div>

								<?php } else { ?>

									<img src="/api/user/thumbnail.php?id=<?= $item['ownerid']; ?>">

									<div class="duration">
										Playlist
									</div>

								<?php } ?>

							</div>

							<div class="search-result-info">

								<h3>
									<?= htmlspecialchars($item['name']); ?>
								</h3>

								<p>
									<?= htmlspecialchars($item['creator']); ?><br>

									<?php if ($item['type'] == 'video') { ?>

										<?= FormatNumber($item['views']); ?> views ·
										<?= FormatDateAgo($item['created_at']); ?>

									<?php } else { ?>

										<?= FormatNumber($item['video_count']); ?> videos ·
										<?= FormatDateAgo($item['created_at']); ?>

									<?php } ?>
								</p>

							</div>

						</div>

					<?php } ?>

				</div>

				<?php if ($totalPages > 1) { ?>

					<div class="pagination">

						<?php if ($page > 1) { ?>

							<a href="/search.php?q=<?= urlencode($query); ?>&page=<?= $page - 1; ?>">
								Previous
							</a>

						<?php } ?>

						<span>
							Page <?= $page; ?> of <?= $totalPages; ?>
						</span>

						<?php if ($page < $totalPages) { ?>

							<a href="/search.php?q=<?= urlencode($query); ?>&page=<?= $page + 1; ?>">
								Next
							</a>

						<?php } ?>

					</div>

				<?php } ?>

			<?php } ?>

		</main>

	</div>

</body>
</html>