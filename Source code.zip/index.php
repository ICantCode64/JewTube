<?php
include __DIR__ . '/core/main.php';

$videos_liked = SqlQuery("SELECT * FROM videos ORDER BY likes DESC LIMIT 5");
$videos_popular = SqlQuery("SELECT * FROM videos ORDER BY views DESC LIMIT 5");
$videos_new = SqlQuery("SELECT * FROM videos ORDER BY published_at DESC LIMIT 5");

function BuildVideoList($result) {
	$list = [];

	while ($video = $result->fetch_assoc()) {
    $path = $_SERVER['DOCUMENT_ROOT'] . "/uploads/videos/" . $video['filename'];
		$userid = $video['authorid'];

		$creator = SqlQuery("
			SELECT username
			FROM users
			WHERE userid = '$userid'
		")->fetch_assoc();

		$video['creator'] = $creator['username'];
    $video['duration'] = FormatDuration(GetVideoDuration($path, $video['videoid']));

		$list[] = $video;
	}

	return $list;
}

$videos_liked_list = BuildVideoList($videos_liked);
$videos_popular_list = BuildVideoList($videos_popular);
$videos_new_list = BuildVideoList($videos_new);

$totalvideos = SqlQuery("
  SELECT COUNT(*) AS total
  FROM videos
")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html>
	<head>
		<title><?= $sitename; ?> - Home</title>
		<?php include __DIR__ . '/main/global.php'; ?>
  </head>
	<body>
		<?php include __DIR__ . '/main/header.php'; ?>
		<div class="layout">
			<?php include __DIR__ . '/main/sidebar.php'; ?>
			<main>
				<div class="banner">
					<h1>Welcome to <?= $sitename; ?></h1>
				</div>
				<div class="section">
					<div class="section-head">
						<h2>Recommended</h2>
						<a class="view-all" href="/Videos.php?filter=recommended">View all (<?= $totalvideos ?>)</a>
					</div>
					<div class="videos">
            <?php foreach ($videos_liked_list as $video) { ?>
						<div class="video" onclick="Redirect('/watch.php?id=<?= $video['videoid'] ?>')">
							<div class="thumb">
                                        <img
                                            class="thumb-image"
                                            src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>"
                                        >

                                        <div class="duration"><?= $video['duration'] ?></div>
                                    </div>
							<div class="title"><?= htmlspecialchars($video['name']) ?></div>
							<div class="meta"><?= htmlspecialchars($video['creator']) ?><br><?= FormatNumber($video['views']) ?> views · <?= FormatDateAgo($video['published_at']) ?></div>
            </div>
            <?php } ?>
					</div>
				</div>
        <div class="section">
          <div class="section-head">
            <h2>Popular</h2>
            <a class="view-all" href="/Videos.php?filter=popular">View all (<?= $totalvideos ?>)</a>
          </div>

          <div class="videos">
            <?php foreach ($videos_popular_list as $video) { ?>
              <div class="video" onclick="Redirect('/watch.php?id=<?= $video['videoid'] ?>')">
                <div class="thumb">
                                        <img
                                            class="thumb-image"
                                            src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>"
                                        >

                                        <div class="duration"><?= $video['duration'] ?></div>
                                    </div>

                <div class="title"><?= htmlspecialchars($video['name']) ?></div>

                <div class="meta">
                  <?= htmlspecialchars($video['creator']) ?><br>
                  <?= FormatNumber($video['views']) ?> views · <?= FormatDateAgo($video['published_at']) ?>
                </div>
              </div>
            <?php } ?>
          </div>
        </div>

        <div class="section">
          <div class="section-head">
            <h2>New</h2>
            <a class="view-all" href="/Videos.php?filter=new">View all (<?= $totalvideos ?>)</a>
          </div>

          <div class="videos">
            <?php foreach ($videos_new_list as $video) { ?>
              <div class="video" onclick="Redirect('/watch.php?id=<?= $video['videoid'] ?>')">
                <div class="thumb">
                                        <img
                                            class="thumb-image"
                                            src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>"
                                        >

                                        <div class="duration"><?= $video['duration'] ?></div>
                                    </div>

                <div class="title"><?= htmlspecialchars($video['name']) ?></div>

                <div class="meta">
                  <?= htmlspecialchars($video['creator']) ?><br>
                  <?= FormatNumber($video['views']) ?> views · <?= FormatDateAgo($video['published_at']) ?>
                </div>
              </div>
            <?php } ?>
          </div>
        </div>
			</main>
		</div>
	</body>
</html>