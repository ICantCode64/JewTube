<?php
include __DIR__ . '/core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$userid = $_SESSION['userid'];
$tab = isset($_GET['tab']) ? SafeVar($_GET['tab']) : "general";

if (!in_array($tab, ["general", "security", "privacy", "avatar"])) {
	$tab = "general";
}

$user = SqlQuery("
	SELECT *
	FROM users
	WHERE userid = '$userid'
")->fetch_assoc();

$message = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	if ($tab == "general") {

		$username = SafeVar($_POST['username']);
		$email = SafeVar($_POST['email']);

		if (trim($username) == "") {
			$error = "Username is required";
		} elseif (trim($email) == "") {
			$error = "Email is required";
		} else {
			SqlQuery("
				UPDATE users
				SET username = '$username',
				email = '$email'
				WHERE userid = '$userid'
			");

			$message = "General settings updated";
			$user['username'] = $username;
			$user['email'] = $email;
		}

	}

	if ($tab == "security") {

		$password = $_POST['password'];
		$password2 = $_POST['password2'];

		if ($password == "" || $password2 == "") {
			$error = "Password is required";
		} elseif ($password != $password2) {
			$error = "Passwords do not match";
		} else {
			$hashed = password_hash($password, PASSWORD_DEFAULT);

			SqlQuery("
				UPDATE users
				SET password = '$hashed'
				WHERE userid = '$userid'
			");

			$message = "Password updated";
		}

	}

	if ($tab == "avatar") {

		if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] != 0) {
			$error = "Choose an image";
		} else {

			$allowed = ["image/jpeg", "image/png", "image/webp"];
			$type = $_FILES['avatar']['type'];

			if (!in_array($type, $allowed)) {
				$error = "Only JPG, PNG, or WEBP allowed";
			} else {

				$dir = $_SERVER['DOCUMENT_ROOT'] . "/uploads/avatars/";

				if (!is_dir($dir)) {
					mkdir($dir, 0777, true);
				}

				$path = $dir . $userid . ".png";

				move_uploaded_file($_FILES['avatar']['tmp_name'], $path);

				$message = "Profile picture updated";
			}
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Settings - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.settings-page {
		padding: 24px;
		width: 100%;
		max-width: 800px;
		margin: 0 auto;
	}

	.page-title {
		font-size: 28px;
		font-weight: normal;
		margin: 0 0 20px;
	}

	.settings-tabs {
		display: flex;
		gap: 18px;
		background: white;
		border: 1px solid #ddd;
		padding: 0 18px;
		margin-bottom: 20px;
		overflow-x: auto;
	}

	.settings-tabs a {
		padding: 15px 0;
		text-decoration: none;
		color: #555;
		font-size: 13px;
		font-weight: bold;
		text-transform: uppercase;
		border-bottom: 3px solid transparent;
		white-space: nowrap;
	}

	.settings-tabs a.active {
		color: #111;
		border-color: #cc0000;
	}

	.settings-box {
		background: white;
		border: 1px solid #ddd;
		padding: 24px;
	}

	.settings-box h2 {
		margin: 0 0 18px;
		font-size: 22px;
		font-weight: normal;
	}

	.settings-box label {
		display: block;
		margin-bottom: 8px;
		color: #333;
		font-size: 14px;
	}

	.settings-box input {
		width: 100%;
		box-sizing: border-box;
		padding: 12px;
		border: 1px solid #ccc;
		font-size: 14px;
		margin-bottom: 18px;
	}

	.settings-box button {
		background: #cc0000;
		color: white;
		border: none;
		padding: 12px 18px;
		font-size: 14px;
		cursor: pointer;
	}

	.settings-box button:hover {
		background: #aa0000;
	}

	.message {
		background: #e9ffe9;
		border: 1px solid #b8e6b8;
		color: #176617;
		padding: 10px;
		margin-bottom: 18px;
		font-size: 14px;
	}

	.error {
		background: #ffe8e8;
		border: 1px solid #ffb4b4;
		color: #a00000;
		padding: 10px;
		margin-bottom: 18px;
		font-size: 14px;
	}

	.avatar-preview {
		width: 90px;
		height: 90px;
		border-radius: 50%;
		object-fit: cover;
		margin-bottom: 18px;
	}

	.settings-note {
		color: #666;
		font-size: 14px;
		margin: 0;
		line-height: 1.5;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="settings-page">

			<h1 class="page-title">Settings</h1>

			<div class="settings-tabs">

				<a class="<?= $tab == 'general' ? 'active' : ''; ?>" href="/Settings.php?tab=general">
					General
				</a>

				<a class="<?= $tab == 'security' ? 'active' : ''; ?>" href="/Settings.php?tab=security">
					Security
				</a>

				<a class="<?= $tab == 'privacy' ? 'active' : ''; ?>" href="/Settings.php?tab=privacy">
					Privacy
				</a>

				<a class="<?= $tab == 'avatar' ? 'active' : ''; ?>" href="/Settings.php?tab=avatar">
					Profile Picture
				</a>

			</div>

			<div class="settings-box">

				<?php if ($message != "") { ?>
					<div class="message">
						<?= htmlspecialchars($message); ?>
					</div>
				<?php } ?>

				<?php if ($error != "") { ?>
					<div class="error">
						<?= htmlspecialchars($error); ?>
					</div>
				<?php } ?>

				<?php if ($tab == "general") { ?>

					<h2>General</h2>

					<form method="POST">

						<label>Username</label>

						<input
							type="text"
							name="username"
							value="<?= htmlspecialchars($user['username']); ?>"
							required
						>

						<label>Email</label>

						<input
							type="email"
							name="email"
							value="<?= htmlspecialchars($user['email']); ?>"
							required
						>

						<button type="submit">
							Save Changes
						</button>

					</form>

				<?php } elseif ($tab == "security") { ?>

					<h2>Security</h2>

					<form method="POST">

						<label>New Password</label>

						<input
							type="password"
							name="password"
							required
						>

						<label>Confirm Password</label>

						<input
							type="password"
							name="password2"
							required
						>

						<button type="submit">
							Change Password
						</button>

					</form>

				<?php } elseif ($tab == "privacy") { ?>

					<h2>Privacy</h2>

					<p class="settings-note">
						Privacy settings coming soon.
					</p>

				<?php } elseif ($tab == "avatar") { ?>

					<h2>Profile Picture</h2>

					<img
						class="avatar-preview"
						src="/api/user/thumbnail.php?id=<?= $userid; ?>&t=<?= time(); ?>"
					>

					<form method="POST" enctype="multipart/form-data">

						<label>Upload Image</label>

						<input
							type="file"
							name="avatar"
							accept="image/png,image/jpeg,image/webp"
							required
						>

						<button type="submit">
							Save Picture
						</button>

					</form>

				<?php } ?>

			</div>

		</main>

	</div>

</body>
</html>