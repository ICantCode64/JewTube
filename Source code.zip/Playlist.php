<?php
include __DIR__ . '/core/main.php';

if (!isset($_GET['id'])) {
	header("Location: /");
	exit;
}

$playlistid = SafeVar($_GET['id']);

$playlistResult = SqlQuery("
	SELECT playlists.*, users.username, users.userid
	FROM playlists
	LEFT JOIN users ON playlists.ownerid = users.userid
	WHERE playlists.playlistid = '$playlistid'
");

if ($playlistResult->num_rows <= 0) {
	header("Location: /");
	exit;
}

$playlist = $playlistResult->fetch_assoc();
$canedit = false;

if ($loggedin && $playlist['ownerid'] == $_SESSION['userid']) {
	$canedit = true;
}


$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
	$page = 1;
}

$perpage = 12;
$offset = ($page - 1) * $perpage;

$totalvideos = SqlQuery("
	SELECT COUNT(*) as total
	FROM playlist_videos
	WHERE playlistid = '$playlistid'
")->fetch_assoc()['total'];

$totalpages = ceil($totalvideos / $perpage);

$videos = SqlQuery("
	SELECT videos.*
	FROM playlist_videos
	INNER JOIN videos ON playlist_videos.videoid = videos.videoid
	WHERE playlist_videos.playlistid = '$playlistid'
	ORDER BY playlist_videos.added_at DESC
	LIMIT $offset, $perpage
");

$videosData = [];

while ($video = $videos->fetch_assoc()) {
	$path = $_SERVER['DOCUMENT_ROOT'] . "/uploads/videos/" . $video['filename'];

	$video['duration'] = FormatDuration(
		GetVideoDuration($path, $video["videoid"])
	);

	$videosData[] = $video;
}
?>
<!DOCTYPE html>
<html>
<head>
	<title><?= htmlspecialchars($playlist['name']); ?> - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.playlist-page {
		padding: 24px;
		width: 100%;
	}

	.playlist-header {
		background: white;
		border: 1px solid #ddd;
		padding: 22px;
		margin-bottom: 22px;
	}

	.playlist-header h1 {
		margin: 0 0 10px;
		font-size: 28px;
		font-weight: normal;
	}

	.playlist-meta {
		color: #666;
		font-size: 14px;
		margin-bottom: 12px;
	}

	.playlist-description {
		color: #444;
		font-size: 14px;
		line-height: 1.5;
		margin: 0;
	}

	.video-row {
		background: white;
		border: 1px solid #ddd;
		padding: 12px;
		display: flex;
		gap: 14px;
		cursor: pointer;
		margin-bottom: 12px;
	}

	.video-row:hover {
		background: #fafafa;
	}

	.video-thumb {
		width: 196px;
		height: 110px;
		background: #eee;
		position: relative;
		flex-shrink: 0;
	}

	.video-thumb img {
		width: 100%;
		height: 100%;
		object-fit: cover;
	}

	.duration {
		position: absolute;
		right: 6px;
		bottom: 6px;
		background: rgba(0,0,0,0.85);
		color: white;
		font-size: 12px;
		padding: 2px 5px;
	}

	.video-info h2 {
		margin: 0 0 8px;
		font-size: 18px;
		font-weight: normal;
		color: #111;
	}

	.video-info p {
		margin: 0;
		color: #666;
		font-size: 13px;
		line-height: 1.5;
	}

	.no-results {
		background: white;
		border: 1px solid #ddd;
		padding: 24px;
		color: #666;
	}

    .pagination {
        display: flex;
        gap: 8px;
        margin-top: 24px;
        flex-wrap: wrap;
    }

    .pagination a {
        background: white;
        border: 1px solid #ddd;
        padding: 8px 14px;
        text-decoration: none;
        color: #333;
        font-size: 14px;
    }

    .pagination a:hover {
        background: #f5f5f5;
    }

    .pagination a.active {
        background: #cc0000;
        border-color: #cc0000;
        color: white;
    }

    .video-info {
        flex: 1;
    }

    .video-actions {
        margin-left: auto;
        display: flex;
        align-items: center;
    }

    .remove-link {
        color: #cc0000;
        text-decoration: none;
        font-size: 13px;
        font-weight: bold;
        padding: 8px;
    }

    .remove-link:hover {
        text-decoration: underline;
    }

	@media (max-width: 700px) {
		.video-row {
			flex-direction: column;
		}

		.video-thumb {
			width: 100%;
			height: auto;
			aspect-ratio: 16 / 9;
		}
	}

    .playlist-actions {
        margin-top: 16px;
    }

    .delete-playlist {
        display: inline-block;
        background: #cc0000;
        color: white;
        text-decoration: none;
        padding: 9px 14px;
        font-size: 13px;
        font-weight: bold;
    }

    .delete-playlist:hover {
        background: #aa0000;
    }
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="playlist-page">

			<div class="playlist-header">

				<h1>
					<?= htmlspecialchars($playlist['name']); ?>
				</h1>

				<div class="playlist-meta">
					By
					<a href="/Channel.php?id=<?= $playlist['userid']; ?>">
						<?= htmlspecialchars($playlist['username']); ?>
					</a>
					· <?= count($videosData); ?> videos
				</div>

				<?php if (!empty($playlist['description'])) { ?>
					<p class="playlist-description">
						<?= nl2br(htmlspecialchars($playlist['description'])); ?>
					</p>
				<?php } ?>

                <?php if ($canedit) { ?>
                    <div class="playlist-actions">
                        <a
                            class="delete-playlist"
                            href="/api/playlist/delete.php?id=<?= $playlistid; ?>"
                            onclick="return confirm('Delete this playlist?')"
                        >
                            Delete Playlist
                        </a>
                    </div>
                <?php } ?>

			</div>

			<?php if (count($videosData) > 0) { ?>

				<?php foreach ($videosData as $video) { ?>

					<div class="video-row">
                        <div
                            class="video-thumb"
                            onclick="Redirect('/watch.php?id=<?= $video['videoid']; ?>')"
                        >

                            <img src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>">

                            <div class="duration">
                                <?= $video['duration']; ?>
                            </div>

                        </div>

                        <div
                            class="video-info"
                            onclick="Redirect('/watch.php?id=<?= $video['videoid']; ?>')"
                        >

                            <h2>
                                <?= htmlspecialchars($video['name']); ?>
                            </h2>

                            <p>
                                <?= FormatNumber($video['views']); ?> views · <?= FormatDateAgo($video['published_at']); ?>
                            </p>

                            <?php if (!empty($video['description'])) { ?>
                                <p>
                                    <?= htmlspecialchars($video['description']); ?>
                                </p>
                            <?php } ?>

                        </div>

                        <?php if ($canedit) { ?>
                            <div class="video-actions">
                                <a
                                    class="remove-link"
                                    href="/api/playlist/remove.php?playlist=<?= $playlistid; ?>&video=<?= $video['videoid']; ?>"
                                    onclick="return confirm('Remove this video from playlist?')"
                                >
                                    Remove
                                </a>
                            </div>
                        <?php } ?>

                    </div>

				<?php } ?>

			<?php } else { ?>

				<div class="no-results">
					No videos in this playlist
				</div>

			<?php } ?>

            <?php if ($totalpages > 1) { ?>

                <div class="pagination">

                    <?php if ($page > 1) { ?>
                        <a href="/Playlist.php?id=<?= $playlistid; ?>&page=<?= $page - 1; ?>">
                            Previous
                        </a>
                    <?php } ?>

                    <?php for ($i = 1; $i <= $totalpages; $i++) { ?>
                        <a
                            class="<?= $i == $page ? 'active' : ''; ?>"
                            href="/Playlist.php?id=<?= $playlistid; ?>&page=<?= $i; ?>"
                        >
                            <?= $i; ?>
                        </a>
                    <?php } ?>

                    <?php if ($page < $totalpages) { ?>
                        <a href="/Playlist.php?id=<?= $playlistid; ?>&page=<?= $page + 1; ?>">
                            Next
                        </a>
                    <?php } ?>

                </div>

            <?php } ?>

		</main>

	</div>

</body>
</html>