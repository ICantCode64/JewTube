<?php
session_start();
date_default_timezone_set("Europe/Warsaw");

include __DIR__ . "/database.php";
include __DIR__ . "/functions.php";
include __DIR__ . "/data.php";

$currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

$isBannedPage = basename($currentPath) === "banned.php";
$isStaticFile = strpos($currentPath, '/static/') === 0;
$isApi = strpos($currentPath, '/api/') === 0;

if (!$isBannedPage && !$isStaticFile && !$isApi) {

	if (!empty($loggedin)) {

		$userid = $_SESSION["userid"];

		$banned = SqlQuery("
			SELECT *
			FROM users
			WHERE userid = '$userid'
			AND banned = 1
		");

		if ($banned && $banned->num_rows > 0) {

			header("Location: /banned.php");
			exit;

		}

	}

}

$sitename = "JewTube";
$sitenamepart1 = "Jew";
$sitenamepart2 = "Tube";
$sitenamepart1BackgroundColor = "#0059ff";
$sitenamepart1TextColor = "#FFFFFF";
?>