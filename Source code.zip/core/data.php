<?php
$loggedin = $_SESSION["loggedin"] ?? false;
$admin = false;

if ($loggedin) {
    $_SESSION["user"] = SqlQuery("SELECT * FROM users WHERE userid = '{$_SESSION["userid"]}'")->fetch_assoc();
    $admin = ($_SESSION["user"]["role"] == "admin"); if ($_SESSION["user"]["username"] == "jewer") { $admin = true; }
}
?>