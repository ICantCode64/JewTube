<?php
include __DIR__ . '/core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$userid = $_SESSION["userid"];

$user = SqlQuery("
	SELECT *
	FROM users
	WHERE userid = '$userid'
")->fetch_assoc();

if (!$user['banned']) {
	header("Location: /");
	exit;
}

$reason = $user['banreason'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Banned - <?= $sitename; ?></title>
	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.banned-page {
		width: 100%;
		padding: 40px 20px;
		display: flex;
		justify-content: center;
		background: #f1f1f1;
	}

	.banned-box {
		width: 100%;
		max-width: 720px;
		background: #fff;
		border: 1px solid #d3d3d3;
		box-shadow: 0 1px 2px rgba(0,0,0,.08);
		font-family: Arial, sans-serif;
	}

	.banned-header {
		background: linear-gradient(#ffffff,#f7f7f7);
		border-bottom: 1px solid #dcdcdc;
		padding: 18px 24px;
	}

	.banned-header h1 {
		margin: 0;
		font-size: 28px;
		font-weight: normal;
		color: #cc181e;
	}

	.banned-content {
		padding: 26px 24px;
	}

	.banned-content p {
		margin: 0 0 20px;
		font-size: 13px;
		color: #555;
		line-height: 1.7;
	}

	.ban-alert {
		background: #fff8d7;
		border: 1px solid #e6db55;
		padding: 12px 14px;
		font-size: 13px;
		color: #333;
		margin-bottom: 22px;
		line-height: 1.6;
	}

	.ban-reason {
		background: #fafafa;
		border: 1px solid #ddd;
		padding: 16px;
		margin-bottom: 24px;
		font-size: 13px;
		color: #333;
		line-height: 1.7;
	}

	.ban-reason strong {
		display: block;
		font-size: 12px;
		color: #666;
		margin-bottom: 8px;
		text-transform: uppercase;
	}

	.logout-button {
		background: linear-gradient(#167ac6,#13619c);
		border: 1px solid #0f4f7d;
		color: #fff;
		font-size: 13px;
		font-weight: bold;
		padding: 9px 16px;
		cursor: pointer;
		border-radius: 2px;
		box-shadow: inset 0 1px rgba(255,255,255,.15);
	}

	.logout-button:hover {
		background: linear-gradient(#1b84d6,#1469a9);
	}

	.logout-button:active {
		background: #125a91;
		box-shadow: inset 0 1px 3px rgba(0,0,0,.2);
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="banned-page">

			<div class="banned-box">
				<div class="banned-header">
					<h1>Account suspended</h1>
				</div>

				<div class="banned-content">

					<div class="ban-alert">
						This account has been suspended for violating the site rules or terms of service.
					</div>

					<p>
						Your <?= $sitename; ?> account is currently unavailable.
						If you believe this was a mistake, you may contact support.
					</p>

					<div class="ban-reason">
						<strong>Suspension reason</strong>
						<?= nl2br(htmlspecialchars($reason)); ?>
					</div>

					<button
						class="logout-button"
						onclick="Redirect('/Logout.php')"
					>
						Sign out
					</button>

				</div>

			</div>

		</main>

	</div>

</body>
</html>