<?php
include __DIR__ . '/core/main.php';

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
	$page = 1;
}

$perpage = 12;
$offset = ($page - 1) * $perpage;

$totalchannels = SqlQuery("
	SELECT COUNT(*) as total
	FROM users
")->fetch_assoc()['total'];

$totalpages = ceil($totalchannels / $perpage);

$channels = SqlQuery("
	SELECT *
	FROM users
	ORDER BY subscribers DESC
	LIMIT $offset, $perpage
");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Channels - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>

	.channels-page {
		padding: 24px;
		width: 100%;
	}

	.page-title {
		font-size: 28px;
		font-weight: normal;
		margin: 0;
	}

	.channels-grid {
		display: flex;
		flex-direction: column;
		gap: 14px;
		margin-top: 20px;
	}

	.channel-card {
		background: white;
		border: 1px solid #ddd;
		padding: 18px;
		display: flex;
		align-items: center;
		gap: 18px;
		cursor: pointer;
		transition: 0.15s;
	}

	.channel-card:hover {
		background: #fafafa;
	}

	.channel-card img {
		width: 72px;
		height: 72px;
		border-radius: 50%;
		object-fit: cover;
		flex-shrink: 0;
	}

	.channel-card-info {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.channel-card h2 {
		margin: 0;
		font-size: 20px;
		font-weight: normal;
		color: #111;
	}

	.channel-card p {
		margin: 0;
		color: #666;
		font-size: 14px;
		line-height: 1.5;
	}

	.pagination {
		display: flex;
		gap: 8px;
		margin-top: 24px;
		flex-wrap: wrap;
	}

	.pagination a {
		background: white;
		border: 1px solid #ddd;
		padding: 8px 14px;
		text-decoration: none;
		color: #333;
		font-size: 14px;
	}

	.pagination a:hover {
		background: #f5f5f5;
	}

	.pagination a.active {
		background: #cc0000;
		border-color: #cc0000;
		color: white;
	}

	</style>

</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="channels-page">

			<h1 class="page-title">
				Channels
			</h1>

			<div class="channels-grid">

				<?php while ($channel = $channels->fetch_assoc()) { ?>

					<div
						class="channel-card"
						onclick="Redirect('/Channel.php?id=<?= $channel['userid']; ?>')"
					>

						<img
							src="/api/user/thumbnail.php?id=<?= $channel['userid']; ?>"
						>

						<div class="channel-card-info">

							<h2>
								<?= htmlspecialchars($channel['username']); ?>
							</h2>

							<p>
								<?= FormatNumber($channel['subscribers']); ?>
								subscribers
							</p>

						</div>

					</div>

				<?php } ?>

			</div>

			<div class="pagination">

				<?php if ($page > 1) { ?>
					<a href="/Channels.php?page=<?= $page - 1; ?>">
						Previous
					</a>
				<?php } ?>

				<?php for ($i = 1; $i <= $totalpages; $i++) { ?>

					<a
						class="<?= $i == $page ? 'active' : ''; ?>"
						href="/Channels.php?page=<?= $i; ?>"
					>
						<?= $i; ?>
					</a>

				<?php } ?>

				<?php if ($page < $totalpages) { ?>
					<a href="/Channels.php?page=<?= $page + 1; ?>">
						Next
					</a>
				<?php } ?>

			</div>

		</main>

	</div>

</body>
</html>