function Redirect(url) {
    window.location.href = url;
}

function Search() {
    var search = document.getElementById("searchtext").value;
    Redirect("/search.php?q=" + search);
}