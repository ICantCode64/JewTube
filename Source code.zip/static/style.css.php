<?php
include __DIR__ . "/../core/main.php";
header("Content-Type: text/css");
?>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: Roboto, Arial, sans-serif;
  background: #f9f9f9;
  color: #111;
  font-size: 14px;
}

header {
  height: 56px;
  background: white;
  border-bottom: 1px solid #ddd;
  display: grid;
  grid-template-columns: 180px 1fr 180px;
  align-items: center;
  padding: 0 16px;
  position: sticky;
  top: 0;
  z-index: 10;
}

.logo {
	font-size: 30px;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;

	color: #555;

	letter-spacing: -2px;

	cursor: pointer;

	display: flex;
	align-items: center;

	user-select: none;
}

.logo span {
	background: <?= $sitenamepart1BackgroundColor; ?>;
	color: <?= $sitenamepart1TextColor; ?>;

	padding: 4px 6px;

	border-radius: 5px;

	margin-right: 2px;

	font-size: 22px;

	line-height: 1;

	position: relative;
	top: -1px;

	display: flex;
	align-items: center;
	justify-content: center;

	text-align: center;

	box-shadow:
		inset 0 1px 0 rgba(255,255,255,0.3),
		0 1px 2px rgba(0,0,0,0.25);

	border: 1px solid rgba(0,0,0,0.15);
}

.search {
  display: flex;
  justify-content: center;
}

.search input {
  width: 520px;
  max-width: calc(100vw - 500px);
  height: 32px;
  border: 1px solid #ccc;
  border-right: none;
  padding: 0 10px;
  font-size: 14px;
}

.search button {
  width: 68px;
  height: 32px;
  border: 1px solid #ccc;
  background: #f8f8f8;
  cursor: pointer;
  color: #555;
}

.actions {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
}

.upload {
  background: #f8f8f8;
  border: 1px solid #ccc;
  padding: 7px 12px;
  font-weight: bold;
  color: #555;
  cursor: pointer;
}

.signin {
  background: #167ac6;
  color: white;
  border: none;
  padding: 8px 13px;
  font-weight: bold;
  cursor: pointer;
  border-radius: 2px;
  white-space: nowrap;
}

.layout {
  display: flex;
}

aside {
  width: 230px;
  background: white;
  border-right: 1px solid #ddd;
  min-height: calc(100vh - 56px);
  padding: 12px 0;
}

aside a {
  display: block;
  color: #333;
  text-decoration: none;
  padding: 11px 24px;
  font-size: 14px;
}

aside a:hover,
aside .active {
  background: #eee;
  font-weight: bold;
}

.side-title {
  padding: 12px 24px 6px;
  color: #777;
  font-size: 12px;
  font-weight: bold;
  text-transform: uppercase;
}

main {
  flex: 1;
  padding: 24px;
}

.banner {
  height: 190px;
  background: linear-gradient(135deg, #444, #999);
  margin-bottom: 24px;
  display: flex;
  align-items: flex-end;
  padding: 22px;
  color: white;
}

.banner h1 {
  margin: 0;
  font-size: 26px;
}

.section {
  background: white;
  border: 1px solid #e3e3e3;
  padding: 18px;
  margin-bottom: 24px;
}

.section-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 18px;
}

.section h2 {
  margin: 0;
  font-size: 18px;
}

.error-box {
	background: #ffe5e5;
	border: 1px solid #ffb3b3;
	color: #cc0000;
	padding: 10px;
	margin-bottom: 16px;
	font-size: 13px;
}

.view-all {
  color: #167ac6;
  text-decoration: none;
  font-weight: bold;
  font-size: 13px;
}

.videos {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
  gap: 18px;
}

.video {
  cursor: pointer;
}

.thumb {
  height: 118px;
  background: linear-gradient(135deg, #555, #999);
  position: relative;
  margin-bottom: 8px;
}

.duration {
  position: absolute;
  bottom: 4px;
  right: 4px;
  background: rgba(0,0,0,0.85);
  color: white;
  font-size: 11px;
  padding: 2px 4px;
  font-weight: bold;
}

.title {
  font-weight: bold;
  line-height: 1.3;
  margin-bottom: 4px;
  color: #111;
}

.meta {
  color: #666;
  font-size: 13px;
  line-height: 1.4;
}

@media (max-width: 850px) {
  aside {
    display: none;
  }

  .actions {
    display: none;
  }

  header {
    padding: 0 12px;
  }

  .logo {
    width: 100px;
    font-size: 21px;
  }

  .search {
    justify-content: flex-start;
  }

  main {
    padding: 14px;
  }
}

.login-page {
  min-height: calc(100vh - 56px);
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding-top: 70px;
  background: #f9f9f9;
}

.login-box {
  width: 360px;
  background: white;
  border: 1px solid #ddd;
  padding: 28px;
}

.login-box h1 {
  margin: 0 0 6px;
  font-size: 24px;
  font-weight: normal;
}

.login-subtitle {
  margin: 0 0 24px;
  color: #666;
  font-size: 14px;
}

.login-box label {
  display: block;
  font-weight: bold;
  margin-bottom: 6px;
  color: #333;
}

.login-box input[type="text"],
.login-box input[type="password"],
.login-box input[type="email"] {
  width: 100%;
  height: 34px;
  border: 1px solid #ccc;
  padding: 0 8px;
  margin-bottom: 16px;
  font-size: 14px;
}

.login-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 18px;
  font-size: 13px;
}

.login-options a,
.login-bottom a {
  color: #167ac6;
  text-decoration: none;
}

.remember {
  display: flex !important;
  align-items: center;
  gap: 6px;
  font-weight: normal !important;
  margin: 0 !important;
}

.remember input {
  margin: 0;
}

.login-submit {
  width: 100%;
  height: 36px;
  background: #167ac6;
  border: none;
  color: white;
  font-weight: bold;
  cursor: pointer;
  border-radius: 2px;
}

.login-bottom {
  border-top: 1px solid #e5e5e5;
  margin-top: 22px;
  padding-top: 18px;
  display: flex;
  justify-content: space-between;
  font-size: 13px;
}

.user-menu {
  position: relative;
  margin-bottom: -10px;
  padding-bottom: 10px;
}

.user-avatar {
	width: 34px;
	height: 34px;
	border-radius: 50%;
	overflow: hidden;
	cursor: pointer;
	user-select: none;
}

.user-avatar img {
	width: 100%;
	height: 100%;
	object-fit: cover;
	display: block;
}

.user-dropdown {
  position: absolute;
  top: 34px;
  right: 0;
  width: 190px;
  background: white;
  border: 1px solid #ddd;
  display: none;
  box-shadow: 0 2px 10px rgba(0,0,0,0.12);
  z-index: 1000;
}

.user-dropdown a {
  display: block;
  padding: 10px 14px;
  color: #333;
  text-decoration: none;
  font-size: 14px;
}

.user-dropdown a:hover {
  background: #f5f5f5;
}

.user-menu:hover .user-dropdown {
  display: block;
}

.channel-page {
	max-width: 1400px;
	margin: 0 auto;
}

.channel-banner {
	height: 220px;
	background: linear-gradient(135deg, #444, #888);
}

.channel-header {
	background: white;
	padding: 24px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 20px;
	border-bottom: 1px solid #ddd;
}

.channel-left {
	display: flex;
	align-items: center;
	gap: 20px;
}

.channel-right {
	display: flex;
	align-items: center;
}

.subscribe-button {
	background: #cc0000;
	color: white;
	border: none;
	padding: 10px 18px;
	font-size: 14px;
	font-weight: bold;
	cursor: pointer;
	text-transform: uppercase;
	border-radius: 2px;
}

.subscribe-button:hover {
	background: #b00000;
}

.unsubscribe-button {
	background: #f1f1f1;
	color: #555;
	border: 1px solid #ccc;
	padding: 10px 18px;
	font-size: 14px;
	font-weight: bold;
	cursor: pointer;
	text-transform: uppercase;
	border-radius: 2px;
}

.unsubscribe-button:hover {
	background: #e5e5e5;
}

.channel-avatar {
	width: 90px;
	height: 90px;
	border-radius: 50%;
	object-fit: cover;
}

.channel-info h1 {
	margin: 0 0 6px;
	font-size: 28px;
	font-weight: normal;
}

.channel-meta {
	color: #666;
	font-size: 14px;
}

.channel-tabs {
	background: white;
	border-bottom: 1px solid #ddd;
	padding: 0 24px;
	display: flex;
	gap: 24px;
}

.channel-tabs a {
	display: inline-block;
	padding: 16px 0;
	text-decoration: none;
	color: #555;
	font-weight: bold;
	font-size: 13px;
	text-transform: uppercase;
	border-bottom: 3px solid transparent;
}

.channel-tabs a.active {
	color: #111;
	border-color: #cc0000;
}

.channel-content {
	padding: 24px;
}

.about-section {
	background: white;
}

.about-row {
	padding: 18px 0;
	border-bottom: 1px solid #eee;
}

.about-row strong {
	display: block;
	margin-bottom: 8px;
	font-size: 15px;
	color: #111;
}

.about-row p {
	margin: 0;
	color: #555;
	line-height: 1.6;
}

.no-results {
	background: white;
	border: 1px solid #ddd;
	padding: 40px 20px;
	text-align: center;
	margin-top: 20px;
}

.no-results p {
	margin: 0;
	font-size: 16px;
	color: #777;
}

.channel-meta {
	margin-top: 6px;
	display: flex;
	flex-direction: column;
	gap: 8px;
	color: #666;
	font-size: 14px;
}

.channel-stats {
	font-weight: bold;
	color: #444;
}

.channel-description {
	max-width: 700px;
	line-height: 1.5;
	color: #666;
}

.channel-info-link {
	width: fit-content;
	margin: 0;
	padding: 0;
	background: none;
	border: none;
	color: #167ac6;
	font-size: 14px;
	font-weight: bold;
	cursor: pointer;
}

.thumb {
	width: 210px;
	height: 118px;
	position: relative;
	background: #000;
	flex-shrink: 0;
	overflow: hidden;
}

.thumb-image {
	width: 100%;
	height: 100%;
	object-fit: cover;
	display: block;
}

.duration {
	position: absolute;
	right: 6px;
	bottom: 6px;
	background: rgba(0,0,0,.85);
	color: white;
	font-size: 11px;
	padding: 2px 4px;
}