<?php
$currentPage = strtolower(basename($_SERVER['PHP_SELF']));
?>

<aside>

	<a class="<?= $currentPage == 'index.php' ? 'active' : ''; ?>" href="/">
		Home
	</a>

	<a class="<?= $currentPage == 'videos.php' ? 'active' : ''; ?>" href="/Videos.php">
		Videos
	</a>

	<a class="<?= $currentPage == 'subscriptions.php' ? 'active' : ''; ?>" href="/Subscriptions.php">
		Subscriptions
	</a>

	<a class="<?= $currentPage == 'channels.php' ? 'active' : ''; ?>" href="/Channels.php">
		Channels
	</a>

	<div class="side-title">
		Library
	</div>

	<a class="<?= $currentPage == 'history.php' ? 'active' : ''; ?>" href="/History.php">
		History
	</a>

	<a class="<?= $currentPage == 'watchlater.php' ? 'active' : ''; ?>" href="/WatchLater.php">
		Watch later
	</a>

	<a class="<?= $currentPage == 'likedvideos.php' ? 'active' : ''; ?>" href="/LikedVideos.php">
		Liked videos
	</a>

	<a class="<?= $currentPage == 'MyPlaylists.php' ? 'active' : ''; ?>" href="/MyPlaylists.php">
		My playlists
	</a>

	<div class="side-title">
		Explore
	</div>

	<a class="<?= $currentPage == 'music.php' ? 'active' : ''; ?>" href="/Music.php">
		Music
	</a>

	<a class="<?= $currentPage == 'gaming.php' ? 'active' : ''; ?>" href="/Gaming.php">
		Gaming
	</a>

	<a class="<?= $currentPage == 'news.php' ? 'active' : ''; ?>" href="/News.php">
		News
	</a>

	<?php if ($admin) { ?>

		<div class="side-title">
			Other
		</div>

		<a class="<?= strpos($currentPage, 'admin') !== false ? 'active' : ''; ?>" href="/admin">
			Admin Panel
		</a>

	<?php } ?>

</aside>