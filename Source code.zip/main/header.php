<header>

	<div class="logo" onclick="window.location='/'">
        <span><?= $sitenamepart1; ?></span><?= $sitenamepart2; ?>
    </div>

	<div class="search">
		<input type="text" id="searchtext" placeholder="Search">
		<button onclick="Search()">Search</button>
	</div>

	<div class="actions">
        <button class="upload" onclick="Redirect('/Studio/Upload.php')">
			Upload
		</button>

		<?php if ($loggedin) { ?>
			<div class="user-menu">

				<div class="user-avatar">
                    <img src="/api/user/thumbnail.php?id=<?= $_SESSION["userid"]; ?>" alt="Avatar">
                </div>

				<div class="user-dropdown">
					<a href="/Channel.php">
						My Channel
					</a>

					<a href="/CreatePlaylist.php">
						Create Playlist
					</a>

					<a href="/Studio">
						Studio
					</a>

					<a href="/Settings.php">
						Settings
					</a>

					<a href="/logout.php">
						Sign out
					</a>
				</div>
			</div>
		<?php } else { ?>
			<button class="signin" onclick="Redirect('/Login.php')">
				Sign in
			</button>
		<?php } ?>
	</div>
</header>