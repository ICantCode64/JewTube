<link rel="stylesheet" href="/static/style.css">
<script src="/static/HelperScript.js?v=<?php echo time(); ?>"></script>