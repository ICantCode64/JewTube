<?php
include __DIR__ . '/core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$userid = $_SESSION["userid"];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
	$page = 1;
}

$perpage = 10;
$offset = ($page - 1) * $perpage;

$totalliked = SqlQuery("
	SELECT COUNT(*) AS total
	FROM rated
	WHERE userid = '$userid'
	AND ratetype = 'like'
")->fetch_assoc()['total'];

$totalpages = ceil($totalliked / $perpage);

$likedvideos = SqlQuery("
	SELECT 
		videos.*,
		rated.rated_at AS liked_at,
		users.username AS creator,
		rated.id AS ratingid
	FROM rated
	INNER JOIN videos ON rated.videoid = videos.videoid
	INNER JOIN users ON videos.authorid = users.userid
	WHERE rated.userid = '$userid'
	AND rated.ratetype = 'like'
	ORDER BY rated.rated_at DESC
	LIMIT $offset, $perpage
");

$totalliked = SqlQuery("
    SELECT COUNT(*) AS total
    FROM rated
    WHERE userid = '$userid'
    AND ratetype = 'like'
")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Liked Videos - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.liked-page {
		padding: 24px;
		width: 100%;
	}

	.page-title {
		font-size: 28px;
		font-weight: normal;
		margin: 0;
	}

	.liked-topbar {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 20px;
	}

	.clear-liked {
		background: #f8f8f8;
		border: 1px solid #ccc;
		padding: 8px 14px;
		font-size: 13px;
		color: #555;
		cursor: pointer;
	}

	.clear-liked:hover {
		background: #eee;
	}

	.liked-list {
		background: white;
		border: 1px solid #ddd;
		padding: 18px;
	}

	.liked-video {
		display: flex;
		gap: 14px;
		padding: 14px 0;
		border-bottom: 1px solid #eee;
		cursor: pointer;
	}

	.liked-video:last-child {
		border-bottom: none;
	}

	.liked-video .thumb {
		width: 210px;
		height: 118px;
		flex-shrink: 0;
		position: relative;
		background: #ddd;
		overflow: hidden;
	}

	.thumb-image {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
	}

	.duration {
		position: absolute;
		right: 6px;
		bottom: 6px;
		background: rgba(0,0,0,0.85);
		color: white;
		font-size: 12px;
		padding: 2px 5px;
	}

	.liked-info h2 {
		margin: 0 0 6px;
		font-size: 18px;
		font-weight: normal;
		color: #111;
	}

	.liked-info p {
		margin: 0;
		color: #666;
		font-size: 14px;
		line-height: 1.5;
	}

	.liked-actions {
		margin-left: auto;
		display: flex;
		align-items: center;
	}

	.remove-liked {
		background: #f8f8f8;
		border: 1px solid #ccc;
		padding: 8px 14px;
		font-size: 13px;
		color: #555;
		cursor: pointer;
	}

	.remove-liked:hover {
		background: #eee;
	}

	.no-results {
		background: white;
		border: 1px solid #ddd;
		padding: 30px;
		text-align: center;
		color: #777;
	}

	.pagination {
		display: flex;
		gap: 8px;
		margin-top: 24px;
		flex-wrap: wrap;
	}

	.pagination a {
		background: white;
		border: 1px solid #ddd;
		padding: 8px 14px;
		text-decoration: none;
		color: #333;
		font-size: 14px;
	}

	.pagination a:hover {
		background: #f5f5f5;
	}

	.pagination a.active {
		background: #cc0000;
		border-color: #cc0000;
		color: white;
	}
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="liked-page">

			<div class="liked-topbar">

				<h1 class="page-title">
					Liked Videos (<?= $totalliked; ?>) 
				</h1>

			</div>

			<?php if ($likedvideos->num_rows == 0) { ?>

				<div class="no-results">
					<p>No liked videos yet.</p>
				</div>

			<?php } else { ?>

				<div class="liked-list">

					<?php while ($video = $likedvideos->fetch_assoc()) { ?>

						<div
							class="liked-video"
							onclick="Redirect('/watch.php?id=<?= $video['videoid']; ?>')"
						>

							<div class="thumb">

								<img
									class="thumb-image"
									src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>"
								>

								<div class="duration">
									<?= FormatDuration($video['duration']) ?>
								</div>

							</div>

							<div class="liked-info">

								<h2>
									<?= htmlspecialchars($video['name']); ?>
								</h2>

								<p>
									<?= htmlspecialchars($video['creator']); ?><br>
									<?= FormatNumber($video['views']); ?> views ·
									liked <?= FormatDateAgo($video['liked_at']); ?>
								</p>

							</div>

							<div class="liked-actions">

								<button
									class="remove-liked"
									onclick="event.stopPropagation(); Redirect('/api/videos/rate.php?id=<?= $video['videoid']; ?>&rate=like')"
								>
									Unlike
								</button>

							</div>

						</div>

					<?php } ?>

				</div>

				<?php if ($totalpages > 1) { ?>

					<div class="pagination">

						<?php if ($page > 1) { ?>
							<a href="/LikedVideos.php?page=<?= $page - 1; ?>">
								Previous
							</a>
						<?php } ?>

						<?php for ($i = 1; $i <= $totalpages; $i++) { ?>

							<a
								class="<?= $i == $page ? 'active' : ''; ?>"
								href="/LikedVideos.php?page=<?= $i; ?>"
							>
								<?= $i; ?>
							</a>

						<?php } ?>

						<?php if ($page < $totalpages) { ?>
							<a href="/LikedVideos.php?page=<?= $page + 1; ?>">
								Next
							</a>
						<?php } ?>

					</div>

				<?php } ?>

			<?php } ?>

		</main>

	</div>

</body>
</html>