<?php
include __DIR__ . '/core/main.php';

if ($loggedin) {
    header("Location: /");
    exit;
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    if (isset($username) && isset($email) && isset($password)) {

        $username = SafeVar($username);
        $email = SafeVar($email);
        $password = SafeVar($password);

        $check = SqlQuery("SELECT * FROM users WHERE username = '$username' OR email = '$email'");

        if ($check->num_rows > 0) {

            $error = "Username or email already exists.";

        } else {
            if (!preg_match('/^[A-Za-z0-9]+$/', $username)) {
                $error = "Username can only contain A-Z, a-z and 0-9.";
            }

            $hashedpassword = password_hash($password, PASSWORD_DEFAULT);

            $result = SqlQuery("
                INSERT INTO users (
                    username,
                    email,
                    password
                ) VALUES (
                    '$username',
                    '$email',
                    '$hashedpassword'
                )
            ");

            LoginAs($conn->insert_id);

            header("Location: /");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title><?= $sitename; ?> - Register</title>
		<?php include __DIR__ . '/main/global.php'; ?>
	</head>

	<body>

		<?php include __DIR__ . '/main/header.php'; ?>

		<div class="login-page">

			<div class="login-box">

				<h1>Create account</h1>

				<p class="login-subtitle">
					Join <?= $sitename; ?>
				</p>

				<?php if ($error != "") { ?>
					<div class="error-box">
						<?= $error; ?>
					</div>
				<?php } ?>

				<form action="/register.php" method="post">

					<label>Username</label>
					<input type="text" name="username" required>

					<label>Email</label>
					<input type="email" name="email" required>

					<label>Password</label>
					<input type="password" name="password" required>

					<button class="login-submit" type="submit">
						Create account
					</button>

				</form>

				<div class="login-bottom">
					<span>Already have an account?</span>

					<a href="/login.php">
						Sign in
					</a>
				</div>

			</div>

		</div>

	</body>
</html>