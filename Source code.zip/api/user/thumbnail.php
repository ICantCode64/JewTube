<?php
include __DIR__ . '/../../core/main.php';

$userid = $_GET['id'];
$userid = SafeVar($userid);

$thumburl = "https://ui-avatars.com/api/?name=JohnDoe&background=167ac6&color=fff";

$result = SqlQuery("SELECT username FROM users WHERE userid = '$userid'");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $username = $row['username'];
    
    if (!file_exists(__DIR__ . "/../../uploads/avatars/$userid.png")) {
        $thumburl = "https://ui-avatars.com/api/?name=$username&background=167ac6&color=fff";
    } else {
        $thumburl = __DIR__ ."/../../uploads/avatars/$userid.png";
    }
}

header("Content-Type: image/png");
echo file_get_contents($thumburl);
?>