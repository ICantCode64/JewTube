<?php
include __DIR__ . "/../../core/main.php";

if (!$loggedin) {
    header("Location: /Login.php");
    exit;
}

$id = SafeVar($_GET['id']);
$userid = $_SESSION["userid"];

$ret = SafeVar($_GET['ret']) ?? 1;

if ($id == $userid) {
    header("Location: /Channel.php?id=$id");
    exit;
}

$result = SqlQuery("SELECT * FROM subscriptions WHERE userid = '$id' AND subscriberid = '$userid'");
if ($result->num_rows > 0) {
    SqlQuery("DELETE FROM subscriptions WHERE userid = '$id' AND subscriberid = '$userid'");
    SqlQuery("UPDATE users SET subscribers = subscribers - 1 WHERE userid = '$id'");
} else {
    SqlQuery("INSERT INTO subscriptions (userid, subscriberid) VALUES ('$id', '$userid')");
    SqlQuery("UPDATE users SET subscribers = subscribers + 1 WHERE userid = '$id'");
}

if ($ret == 1) {
    header("Location: /Channel.php?id=$id");
    exit;
} else if ($ret == 2) {
    header("Location: /Subscriptions.php");
    exit;
} else {
    header("Location: /");
    exit;
}
?>