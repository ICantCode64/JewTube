<?php
include __DIR__ . '/../../core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$id = SafeVar($_GET['id']);
$rate = SafeVar($_GET['rate']);

$userid = $_SESSION["userid"];

$newrate = ($rate == "like") ? "like" : "dislike";

$oldrating = SqlQuery("
	SELECT *
	FROM rated
	WHERE userid = '$userid'
	AND videoid = '$id'
");

if ($oldrating->num_rows > 0) {

	$row = $oldrating->fetch_assoc();
	$oldrate = $row['ratetype'];

	if ($oldrate == $newrate) {

		if ($oldrate == "like") {

			SqlQuery("
				UPDATE videos
				SET likes = likes - 1
				WHERE videoid = '$id'
			");

		} else {

			SqlQuery("
				UPDATE videos
				SET dislikes = dislikes - 1
				WHERE videoid = '$id'
			");

		}

		SqlQuery("
			DELETE FROM rated
			WHERE userid = '$userid'
			AND videoid = '$id'
		");

	} else {

		if ($oldrate == "like") {

			SqlQuery("
				UPDATE videos
				SET likes = likes - 1
				WHERE videoid = '$id'
			");

			SqlQuery("
				UPDATE videos
				SET dislikes = dislikes + 1
				WHERE videoid = '$id'
			");

		} else {

			SqlQuery("
				UPDATE videos
				SET dislikes = dislikes - 1
				WHERE videoid = '$id'
			");

			SqlQuery("
				UPDATE videos
				SET likes = likes + 1
				WHERE videoid = '$id'
			");

		}

		SqlQuery("
			UPDATE rated
			SET ratetype = '$newrate'
			WHERE userid = '$userid'
			AND videoid = '$id'
		");

	}

} else {

	if ($newrate == "like") {

		SqlQuery("
			UPDATE videos
			SET likes = likes + 1
			WHERE videoid = '$id'
		");

	} else {

		SqlQuery("
			UPDATE videos
			SET dislikes = dislikes + 1
			WHERE videoid = '$id'
		");

	}

	SqlQuery("
		INSERT INTO rated (
			videoid,
			userid,
			ratetype
		) VALUES (
			'$id',
			'$userid',
			'$newrate'
		)
	");
}

header("Location: /watch.php?id=$id");
exit;
?>