<?php
include __DIR__ . '/../../core/main.php';

$id = $_GET['id'];
$id = SafeVar($id);

$result = SqlQuery("SELECT * FROM videos WHERE videoid = '$id' LIMIT 1");
if ($result->num_rows == 0) {
    header("Location: /");
    exit;
}

$filename = $result->fetch_assoc()["filename"];
$filenamename = explode(".", $filename)[0];

header("Content-Type: image/png");
echo file_get_contents(__DIR__ . "/../../uploads/video_thumbnails/$filenamename.png");
?>