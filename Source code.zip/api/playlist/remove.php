<?php
include __DIR__ . '/../../core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

if (
	!isset($_GET['playlist']) ||
	!isset($_GET['video'])
) {
	header("Location: /");
	exit;
}

$playlistid = SafeVar($_GET['playlist']);
$videoid = SafeVar($_GET['video']);
$userid = $_SESSION['userid'];

$playlist = SqlQuery("
	SELECT *
	FROM playlists
	WHERE playlistid = '$playlistid'
	AND ownerid = '$userid'
");

if ($playlist->num_rows <= 0) {
	header("Location: /");
	exit;
}

SqlQuery("
	DELETE FROM playlist_videos
	WHERE playlistid = '$playlistid'
	AND videoid = '$videoid'
");

header("Location: /Playlist.php?id=$playlistid");
exit;
?>