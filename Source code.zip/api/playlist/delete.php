<?php
include __DIR__ . '/../../core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

if (!isset($_GET['id'])) {
	header("Location: /");
	exit;
}

$playlistid = SafeVar($_GET['id']);
$userid = $_SESSION['userid'];

$playlist = SqlQuery("
	SELECT *
	FROM playlists
	WHERE playlistid = '$playlistid'
	AND ownerid = '$userid'
");

if ($playlist->num_rows <= 0) {
	header("Location: /");
	exit;
}

SqlQuery("
	DELETE FROM playlist_videos
	WHERE playlistid = '$playlistid'
");

SqlQuery("
	DELETE FROM playlists
	WHERE playlistid = '$playlistid'
	AND ownerid = '$userid'
");

header("Location: /MyPlaylists.php");
exit;
?>