<?php
include __DIR__ . '/../../core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$id = SafeVar($_GET['id']);
$userid = $_SESSION["userid"];

SqlQuery("
	DELETE FROM history
	WHERE id = '$id'
	AND userid = '$userid'
");

header("Location: /History.php");
exit;
?>