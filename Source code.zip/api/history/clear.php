<?php
include __DIR__ . '/../../core/main.php';

if (!$loggedin) {
    header("Location: /Login.php");
    exit;
}

$userid = $_SESSION["userid"];

SqlQuery("
    DELETE FROM history
    WHERE userid = '$userid'
");

header("Location: /History.php");
exit;
?>