<?php
include __DIR__ . '/core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$userid = $_SESSION["userid"];
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
	$page = 1;
}

$perpage = 12;
$offset = ($page - 1) * $perpage;

$total = SqlQuery("
	SELECT COUNT(*) as total
	FROM subscriptions
	WHERE subscriberid = '$userid'
")->fetch_assoc()['total'];

$totalpages = ceil($total / $perpage);

$subscriptions = SqlQuery("
	SELECT users.*
	FROM subscriptions
	INNER JOIN users ON subscriptions.userid = users.userid
	WHERE subscriptions.subscriberid = '$userid'
	ORDER BY users.username ASC
	LIMIT $offset, $perpage
");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Subscriptions - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.subscriptions-page {
		padding: 24px;
		width: 100%;
	}

	.page-title {
		font-size: 28px;
		font-weight: normal;
		margin: 0 0 20px;
	}

	.sub-list {
		display: flex;
		flex-direction: column;
		gap: 14px;
	}

	.sub-card {
		background: white;
		border: 1px solid #ddd;
		padding: 18px;
		display: flex;
		align-items: center;
		gap: 18px;
		cursor: pointer;
	}

	.sub-card:hover {
		background: #fafafa;
	}

	.sub-card img {
		width: 72px;
		height: 72px;
		border-radius: 50%;
		object-fit: cover;
	}

	.sub-info h2 {
		margin: 0 0 6px;
		font-size: 20px;
		font-weight: normal;
		color: #111;
	}

	.sub-info p {
		margin: 0;
		color: #666;
		font-size: 14px;
	}

	.no-results {
		background: white;
		border: 1px solid #ddd;
		padding: 30px;
		text-align: center;
		color: #777;
	}

    .pagination {
        display: flex;
        gap: 8px;
        margin-top: 24px;
        flex-wrap: wrap;
    }

    .pagination a {
        background: white;
        border: 1px solid #ddd;
        padding: 8px 14px;
        text-decoration: none;
        color: #333;
        font-size: 14px;
    }

    .pagination a:hover {
        background: #f5f5f5;
    }

    .pagination a.active {
        background: #cc0000;
        border-color: #cc0000;
        color: white;
    }

    .sub-actions {
        margin-left: auto;
        display: flex;
        align-items: center;
    }
	</style>
</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="subscriptions-page">

			<h1 class="page-title">Subscriptions</h1>

			<?php if ($subscriptions->num_rows == 0) { ?>

				<div class="no-results">
					<p>You are not subscribed to anyone yet.</p>
				</div>

			<?php } else { ?>

				<div class="sub-list">

					<?php while ($channel = $subscriptions->fetch_assoc()) { ?>

						<div
							class="sub-card"
							onclick="Redirect('/Channel.php?id=<?= $channel['userid']; ?>')"
						>

							<img src="/api/user/thumbnail.php?id=<?= $channel['userid']; ?>">

							<div class="sub-info">

								<h2>
									<?= htmlspecialchars($channel['username']); ?>
								</h2>

								<p>
									<?= FormatNumber($channel['subscribers']); ?>
									subscribers
								</p>

							</div>

                            <div class="sub-actions">

                                <button
                                    class="unsubscribe-button"
                                    onclick="event.stopPropagation(); Redirect('/api/user/subscribe.php?id=<?= $channel['userid']; ?>&ret=2')"
                                >
                                    Unsubscribe
                                </button>

                            </div>

						</div>

					<?php } ?>

				</div>

                <?php if ($totalpages > 1) { ?>
                    <div class="pagination">

                        <?php if ($page > 1) { ?>
                            <a href="/Subscriptions.php?page=<?= $page - 1; ?>">Previous</a>
                        <?php } ?>

                        <?php for ($i = 1; $i <= $totalpages; $i++) { ?>
                            <a
                                class="<?= $i == $page ? 'active' : ''; ?>"
                                href="/Subscriptions.php?page=<?= $i; ?>"
                            >
                                <?= $i; ?>
                            </a>
                        <?php } ?>

                        <?php if ($page < $totalpages) { ?>
                            <a href="/Subscriptions.php?page=<?= $page + 1; ?>">Next</a>
                        <?php } ?>

                    </div>
                <?php } ?>

			<?php } ?>

		</main>

	</div>

</body>
</html>