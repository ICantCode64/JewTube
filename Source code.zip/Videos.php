<?php
include __DIR__ . '/core/main.php';

$filter = isset($_GET['filter']) ? SafeVar($_GET['filter']) : "all";

$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$perPage = 12;
$offset = ($page - 1) * $perPage;

$text = "All";
$orderBy = "videoid DESC";

if ($filter == "recommended") {
	$orderBy = "likes DESC";
	$text = "Recommended";
} else if ($filter == "popular") {
	$orderBy = "views DESC";
	$text = "Popular";
} else if ($filter == "new") {
	$orderBy = "published_at DESC";
	$text = "New";
}

$totalVideos = SqlQuery("
	SELECT COUNT(*) AS total
	FROM videos
")->fetch_assoc()['total'];

$totalPages = max(1, ceil($totalVideos / $perPage));

$videos = SqlQuery("
	SELECT *
	FROM videos
	ORDER BY $orderBy
	LIMIT $perPage OFFSET $offset
");

function BuildVideoList($result) {
	$list = [];

	while ($video = $result->fetch_assoc()) {
		$userid = $video['authorid'];

		$creator = SqlQuery("
			SELECT username
			FROM users
			WHERE userid = '$userid'
		")->fetch_assoc();

		$video['creator'] = $creator['username'] ?? "Unknown";

		if (empty($video['duration'])) {
			$video['duration'] = GetVideoDuration(
				$_SERVER['DOCUMENT_ROOT'] . "/uploads/videos/" . $video['filename'],
				$video['videoid']
			);
		}

		$video['duration'] = FormatDuration($video['duration']);

		$list[] = $video;
	}

	return $list;
}

$videos_list = BuildVideoList($videos);
?>
<!DOCTYPE html>
<html>
<head>
	<title><?= $sitename; ?> - Home</title>
	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.pagination {
		margin: 24px 0;
		display: flex;
		gap: 14px;
		align-items: center;
		justify-content: center;
		font-size: 14px;
	}

	.pagination a {
		color: #065fd4;
		text-decoration: none;
	}

	.pagination a:hover {
		text-decoration: underline;
	}

	.pagination span {
		color: #666;
	}
	</style>
</head>

<body>
	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">
		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main>
			<div class="banner">
				<h1><?= $text ?> videos on <?= $sitename; ?></h1>
			</div>

			<div class="section">
				<div class="section-head"></div>

				<div class="videos">
					<?php foreach ($videos_list as $video) { ?>
						<div class="video" onclick="Redirect('/watch.php?id=<?= $video['videoid'] ?>')">
							<div class="thumb">
								<img
									class="thumb-image"
									src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>"
								>

								<div class="duration">
									<?= $video['duration'] ?>
								</div>
							</div>

							<div class="title">
								<?= htmlspecialchars($video['name']) ?>
							</div>

							<div class="meta">
								<?= htmlspecialchars($video['creator']) ?><br>
								<?= FormatNumber($video['views']) ?> views · <?= FormatDateAgo($video['published_at']) ?>
							</div>
						</div>
					<?php } ?>
				</div>

				<?php if ($totalPages > 1) { ?>
					<div class="pagination">
						<?php if ($page > 1) { ?>
							<a href="/Videos.php?filter=<?= urlencode($filter); ?>&page=<?= $page - 1; ?>">
								Previous
							</a>
						<?php } ?>

						<span>Page <?= $page; ?> of <?= $totalPages; ?></span>

						<?php if ($page < $totalPages) { ?>
							<a href="/Videos.php?filter=<?= urlencode($filter); ?>&page=<?= $page + 1; ?>">
								Next
							</a>
						<?php } ?>
					</div>
				<?php } ?>

			</div>
		</main>
	</div>
</body>
</html>