<?php
include __DIR__ . '/core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

$userid = $_SESSION['userid'];
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$name = SafeVar($_POST['name']);
	$description = SafeVar($_POST['description']);

	if (trim($name) == "") {
		$error = "Playlist name is required";
	} else {

		SqlQuery("
			INSERT INTO playlists
			(ownerid, name, description)
			VALUES
			('$userid', '$name', '$description')
		");

		$newid = SqlQuery("
			SELECT playlistid
			FROM playlists
			WHERE ownerid = '$userid'
			ORDER BY playlistid DESC
			LIMIT 1
		")->fetch_assoc()['playlistid'];

		header("Location: /Playlist.php?id=$newid");
		exit;
	}
}
?>
<!DOCTYPE html>
<html>
<head>

	<title>Create Playlist - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>
	.create-page {
		padding: 30px;
		width: 100%;
		max-width: 700px;
		margin: 0 auto;
	}

	.create-box {
		background: white;
		border: 1px solid #ddd;
		padding: 24px;
	}

	.create-box h1 {
		margin: 0 0 20px;
		font-size: 28px;
		font-weight: normal;
	}

	label {
		display: block;
		margin-bottom: 8px;
		font-size: 14px;
		color: #333;
	}

	.create-box input,
	.create-box textarea {
		width: 100%;
		padding: 12px;
		border: 1px solid #ccc;
		font-size: 14px;
		margin-bottom: 18px;
		background: white;
		box-sizing: border-box;
	}

	.create-box textarea {
		min-height: 120px;
		resize: vertical;
	}

	.create-box button {
		background: #cc0000;
		color: white;
		border: none;
		padding: 12px 18px;
		font-size: 14px;
		cursor: pointer;
	}

	button:hover {
		background: #aa0000;
	}

	.error {
		background: #ffe8e8;
		border: 1px solid #ffb4b4;
		color: #a00000;
		padding: 10px;
		margin-bottom: 18px;
		font-size: 14px;
	}
	</style>

</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="create-page">

			<div class="create-box">

				<h1>Create Playlist</h1>

				<?php if ($error != "") { ?>
					<div class="error">
						<?= htmlspecialchars($error); ?>
					</div>
				<?php } ?>

				<form method="POST">

					<label>
						Name
					</label>

					<input
						type="text"
						name="name"
						required
						maxlength="100"
					>

					<label>
						Description
					</label>

					<textarea name="description"></textarea>

					<button type="submit">
						Create Playlist
					</button>

				</form>

			</div>

		</main>

	</div>

</body>
</html>