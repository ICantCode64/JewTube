<?php
include __DIR__ . '/core/main.php';

if (!$loggedin) {
	header("Location: /Login.php");
	exit;
}

if (!isset($_GET['video'])) {
	header("Location: /");
	exit;
}

$videoid = SafeVar($_GET['video']);
$userid = $_SESSION['userid'];

$videoResult = SqlQuery("
	SELECT *
	FROM videos
	WHERE videoid = '$videoid'
");

if ($videoResult->num_rows <= 0) {
	header("Location: /");
	exit;
}

$video = $videoResult->fetch_assoc();
$videotitle = $video['name'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$playlistid = SafeVar($_POST['playlistid']);

	$playlist = SqlQuery("
		SELECT *
		FROM playlists
		WHERE playlistid = '$playlistid'
		AND ownerid = '$userid'
	");

	if ($playlist->num_rows > 0) {

		$exists = SqlQuery("
			SELECT *
			FROM playlist_videos
			WHERE playlistid = '$playlistid'
			AND videoid = '$videoid'
		");

		if ($exists->num_rows <= 0) {

			SqlQuery("
				INSERT INTO playlist_videos
				(playlistid, videoid)
				VALUES
				('$playlistid', '$videoid')
			");

		}

		header("Location: /Playlist.php?id=$playlistid");
		exit;
	}
}

$playlists = SqlQuery("
	SELECT *
	FROM playlists
	WHERE ownerid = '$userid'
	ORDER BY playlistid DESC
");
?>
<!DOCTYPE html>
<html>
<head>

	<title>Add To Playlist - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>

	.add-page {
		padding: 30px;
		width: 100%;
		max-width: 700px;
		margin: 0 auto;
	}

	.add-box {
		background: white;
		border: 1px solid #ddd;
		padding: 24px;
	}

	.add-box h1 {
		margin: 0 0 20px;
		font-size: 28px;
		font-weight: normal;
	}

	select {
		width: 100%;
		padding: 12px;
		border: 1px solid #ccc;
		font-size: 14px;
		margin-bottom: 18px;
		background: white;
	}

	.add-box button {
        background: #cc0000;
        color: white;
        border: none;
        padding: 12px 18px;
        font-size: 14px;
        cursor: pointer;
    }

    .add-box button:hover {
        background: #aa0000;
    }

	button:hover {
		background: #aa0000;
	}

	.no-playlists {
		color: #666;
		font-size: 14px;
	}

    .video-preview {
        display: flex;
        gap: 14px;
        margin-bottom: 22px;
        cursor: pointer;
    }

    .video-preview:hover .video-title {
        color: #cc0000;
    }

    .video-preview img {
        width: 220px;
        height: 124px;
        object-fit: cover;
        background: #eee;
        flex-shrink: 0;
    }

    .video-preview-info {
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .video-title {
        font-size: 18px;
        color: #111;
        margin-bottom: 8px;
        transition: 0.15s;
    }

    .video-meta {
        font-size: 13px;
        color: #666;
    }

	</style>

</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

	<div class="layout">

		<?php include __DIR__ . '/main/sidebar.php'; ?>

		<main class="add-page">

			<div class="add-box">

				<h1>
					Add To Playlist
				</h1>

                <div
                    class="video-preview"
                    onclick="Redirect('/watch.php?id=<?= $videoid; ?>')"
                >

                    <img src="/api/videos/thumbnail.php?id=<?= $videoid; ?>">

                    <div class="video-preview-info">

                        <div class="video-title">
                            <?= htmlspecialchars($videotitle); ?>
                        </div>

                        <div class="video-meta">
                            Click to watch video
                        </div>

                    </div>

                </div>

				<?php if ($playlists->num_rows > 0) { ?>

					<form method="POST">

						<select name="playlistid" required>

							<option value="">
								Select playlist
							</option>

							<?php while ($playlist = $playlists->fetch_assoc()) { ?>

								<option value="<?= $playlist['playlistid']; ?>">
									<?= htmlspecialchars($playlist['name']); ?>
								</option>

							<?php } ?>

						</select>

						<button type="submit">
							Add Video
						</button>

					</form>

				<?php } else { ?>

					<div class="no-playlists">
						You have no playlists
					</div>

				<?php } ?>

			</div>

		</main>

	</div>

</body>
</html>