<?php
include __DIR__ . '/core/main.php';

if (isset($_GET['id'])) {
	$userid = SafeVar($_GET['id']);
} else {
	if ($loggedin) {
		$userid = $_SESSION["userid"];
	} else {
		header("Location: /Login.php");
		exit;
	}
}

$result = SqlQuery("SELECT * FROM users WHERE userid = '$userid'");

if ($result->num_rows <= 0) {
	header("Location: /");
	exit;
}

$user = $result->fetch_assoc();

$username = $user['username'];
$email = $user['email'];

$description = isset($user['description']) ? $user['description'] : "";

$shortdescription = substr($description, 0, 50);

if (strlen($description) > 50) {
	$shortdescription .= "...";
}
$subscribers = $user['subscribers'];
$avatar = "/api/user/thumbnail.php?id=$userid";
$tab = isset($_GET['tab']) ? SafeVar($_GET['tab']) : "home";

$subscribed = false;

if ($loggedin) {
    $result = SqlQuery("SELECT * FROM subscriptions WHERE userid = '$userid' AND subscriberid = '$_SESSION[userid]'");
    if ($result->num_rows > 0) {
        $subscribed = true;
    }
}

$videos = SqlQuery("SELECT * FROM videos WHERE authorid = '$userid' ORDER BY videoid DESC");
$videos_popular = SqlQuery("SELECT * FROM videos WHERE authorid = '$userid' ORDER BY views DESC LIMIT 10");

$videosData = [];
$videosData_popular = [];

while ($vid = $videos->fetch_assoc()) {
	$path = $_SERVER['DOCUMENT_ROOT'] . "/uploads/videos/" . $vid['filename'];
	$vid['duration'] = FormatDuration(
		GetVideoDuration($path, $vid["videoid"])
	);
	$videosData[] = $vid;
}

while ($vid = $videos_popular->fetch_assoc()) {
	$path = $_SERVER['DOCUMENT_ROOT'] . "/uploads/videos/" . $vid['filename'];
	$vid['duration'] = FormatDuration(
		GetVideoDuration($path, $vid["videoid"])
	);
	$videosData_popular[] = $vid;
}

$playlists = SqlQuery("
	SELECT *
	FROM playlists
	WHERE ownerid = '$userid'
	ORDER BY playlistid DESC
");
?>
<!DOCTYPE html>
<html>
<head>
	<title><?= $username; ?> - <?= $sitename; ?></title>

	<?php include __DIR__ . '/main/global.php'; ?>

	<style>

	.channel-page {
		max-width: 1400px;
		margin: 0 auto;
	}

	.channel-banner {
		height: 220px;
		background: linear-gradient(135deg, #444, #888);
	}

	.channel-header {
		background: white;
		padding: 24px;
		display: flex;
		align-items: center;
		gap: 20px;
		border-bottom: 1px solid #ddd;
	}

	.channel-avatar {
		width: 90px;
		height: 90px;
		border-radius: 50%;
		object-fit: cover;
	}

	.channel-info h1 {
		margin: 0 0 6px;
		font-size: 28px;
		font-weight: normal;
	}

	.channel-meta {
		color: #666;
		font-size: 14px;
	}

	.channel-info-link {
		margin-left: 10px;
		color: #167ac6;
		background: none;
		border: none;
		cursor: pointer;
		font-weight: bold;
		font-size: 14px;
	}

	.channel-tabs {
		background: white;
		border-bottom: 1px solid #ddd;
		padding: 0 24px;
		display: flex;
		gap: 24px;
	}

	.channel-tabs a {
		display: inline-block;
		padding: 16px 0;
		text-decoration: none;
		color: #555;
		font-weight: bold;
		font-size: 13px;
		text-transform: uppercase;
		border-bottom: 3px solid transparent;
	}

	.channel-tabs a.active {
		color: #111;
		border-color: #cc0000;
	}

	.channel-content {
		padding: 24px 0;
	}

	.channel-content .section {
		width: 100%;
	}

	.popup-bg {
		position: fixed;
		inset: 0;
		background: rgba(0,0,0,0.55);
		display: none;
		align-items: center;
		justify-content: center;
		z-index: 9999;
	}

	.channel-popup {
		width: 430px;
		max-width: 92%;
		background: white;
		border: 1px solid #ccc;
		box-shadow: 0 4px 18px rgba(0,0,0,0.3);
	}

	.popup-head {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 14px 18px;
		border-bottom: 1px solid #ddd;
	}

	.popup-head h2 {
		margin: 0;
		font-size: 20px;
		font-weight: normal;
	}

	.popup-head button {
		background: #f8f8f8;
		border: 1px solid #ccc;
		padding: 6px 12px;
		cursor: pointer;
	}

	.popup-row {
		padding: 16px 18px;
		border-bottom: 1px solid #eee;
	}

	.popup-row strong {
		display: block;
		margin-bottom: 8px;
		color: #111;
	}

	.popup-row p {
		margin: 0;
		color: #555;
		line-height: 1.5;
	}

	@media (max-width: 850px) {

		.channel-header {
			padding: 18px;
		}

		.channel-tabs {
			padding: 0 18px;
			gap: 18px;
			overflow-x: auto;
		}

	}

	</style>

</head>

<body>

	<?php include __DIR__ . '/main/header.php'; ?>

    <div class="layout">

        <?php include __DIR__ . '/main/sidebar.php'; ?>

        <main class="channel-main">

            <div class="channel-page">

            <div class="channel-banner"></div>

            <div class="channel-header">

                <div class="channel-left">

                    <img class="channel-avatar" src="<?= $avatar; ?>">

                    <div class="channel-info">

                        <h1><?= htmlspecialchars($username); ?></h1>

                        <div class="channel-meta">

                            <div class="channel-stats">
                                <?= FormatNumber($subscribers); ?> subscribers
                            </div>

                            <button
                                class="channel-info-link"
                                onclick="OpenChannelInfo()">
                                More
                            </button>

                        </div>

                    </div>

                </div>

                <div class="channel-right">
                    <?php if ($loggedin && $userid == $_SESSION["userid"]) { ?>
                        <button class="subscribe-button" onclick="Redirect('/Studio')">
                            Studio
                        </button>
                    <?php } else { ?>
                    <?php if (!$subscribed) { ?>
                    <button class="subscribe-button" onclick="Redirect('/api/user/subscribe.php?id=<?= $userid; ?>')">
                        Subscribe
                    </button>
                    <?php } else { ?>
                    <button class="unsubscribe-button" onclick="Redirect('/api/user/subscribe.php?id=<?= $userid; ?>')">
                        Unsubscribe
                    </button>
                    <?php } ?>
                    <?php } ?>

                </div>

            </div>

            <div class="channel-tabs">

                <a class="<?= $tab == 'home' ? 'active' : ''; ?>" href="/Channel.php?id=<?= $userid; ?>">
                    Home
                </a>

                <a class="<?= $tab == 'videos' ? 'active' : ''; ?>" href="/Channel.php?id=<?= $userid; ?>&tab=videos">
                    Videos
                </a>

                <a class="<?= $tab == 'playlists' ? 'active' : ''; ?>" href="/Channel.php?id=<?= $userid; ?>&tab=playlists">
                    Playlists
                </a>

                <a class="<?= $tab == 'about' ? 'active' : ''; ?>" href="/Channel.php?id=<?= $userid; ?>&tab=about">
                    About
                </a>

            </div>

            <div class="channel-content">

                <?php if ($tab == "videos") { ?>

                    <div class="section">
                        <div class="section-head">
                            <h2>Videos</h2>
                        </div>

                        <div class="videos">
                            <?php foreach ($videosData as $video) { ?>
                                <div class="video" onclick="Redirect('/watch.php?id=<?= $video['videoid'] ?>')">
                                    <div class="thumb">
                                        <img
                                            class="thumb-image"
                                            src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>"
                                        >

                                        <div class="duration"><?= $video['duration'] ?></div>
                                    </div>

                                    <div class="title"><?= htmlspecialchars($video['name']); ?></div>

                                    <div class="meta">
                                        <?= FormatNumber($video['views']); ?> views · <?= FormatDateAgo($video['published_at']) ?>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>

                        <?php if ($videos->num_rows == 0) { ?>
                            <div class="no-results">
                                <p>No videos found</p>
                            </div>
                        <?php } ?>
                    </div>

                <?php } elseif ($tab == "playlists") { ?>

					<div class="section">

						<div class="section-head">
							<h2>Playlists</h2>
						</div>

						<div class="videos">

							<?php while ($playlist = $playlists->fetch_assoc()) { ?>

								<div
									class="video"
									onclick="Redirect('/Playlist.php?id=<?= $playlist['playlistid']; ?>')"
								>

									<div class="thumb">

										<img
											class="thumb-image"
											src="/api/user/thumbnail.php?id=<?= $playlist['ownerid']; ?>"
										>

										<div class="duration">
											Playlist
										</div>

									</div>

									<div class="title">
										<?= htmlspecialchars($playlist['name']); ?>
									</div>

									<div class="meta">
										<?= htmlspecialchars($playlist['description']); ?>
									</div>

								</div>

							<?php } ?>

						</div>

						<?php if ($playlists->num_rows == 0) { ?>
							<div class="no-results">
								<p>No playlists found</p>
							</div>
						<?php } ?>

					</div>

				<?php } elseif ($tab == "about") { ?>

                    <div class="section">

                        <div class="section-head">
                            <h2>About</h2>
                        </div>

                        <div class="about-section">

                            <div class="about-row">
                                <strong>Channel</strong>

                                <p>
                                    <?= htmlspecialchars($username); ?>
                                </p>
                            </div>

                            <div class="about-row">
                                <strong>Description</strong>

                                <p>
                                    <?= nl2br(htmlspecialchars($description)); ?>
                                </p>
                            </div>

                            <div class="about-row">
                                <strong>Joined</strong>

                                <p>
                                    <?= date("F j, Y", strtotime($user['created_at'])); ?>
                                </p>
                            </div>

                        </div>

                    </div>

                <?php } else { ?>

                    <div class="section">
                        <div class="section-head">
                            <h2>Popular</h2>
                        </div>

                        <div class="videos">
                            <?php foreach ($videosData_popular as $video) { ?>
                                <div class="video" onclick="Redirect('/watch.php?id=<?= $video['videoid'] ?>')">
                                    <div class="thumb">
                                        <img
                                            class="thumb-image"
                                            src="/api/videos/thumbnail.php?id=<?= $video['videoid']; ?>"
                                        >

                                        <div class="duration"><?= $video['duration'] ?></div>
                                    </div>

                                    <div class="title"><?= htmlspecialchars($video['name']); ?></div>

                                    <div class="meta">
                                        <?= FormatNumber($video['views']); ?> views · <?= FormatDateAgo($video['published_at']) ?>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>

                        <?php if ($videos->num_rows == 0) { ?>
                            <div class="no-results">
                                <p>No videos found</p>
                            </div>
                        <?php } ?>
                    </div>

                <?php } ?>
            </div>

        	</div>

        </main>

    </div>

    <div
        id="channelInfoPopup"
		class="popup-bg"
		onclick="CloseChannelInfo()"
	>

		<div
			class="channel-popup"
			onclick="event.stopPropagation()"
		>

			<div class="popup-head">

				<h2>About</h2>

				<button onclick="CloseChannelInfo()">
					Close
				</button>

			</div>

			<div class="popup-row">

                <strong>Description</strong>

                <p>
                    <?= nl2br(htmlspecialchars($description)); ?>
                </p>

            </div>

            <div class="popup-row">

                <strong>Joined</strong>

                <p>
                    <?= date("F j, Y", strtotime($user['created_at'])); ?>
                </p>

            </div>

            <div class="popup-row">

                <strong>Channel</strong>

                <p>
                    <?= htmlspecialchars($username); ?>
                </p>

            </div>

		</div>

	</div>

	<script>

	function OpenChannelInfo() {
		document.getElementById(
			"channelInfoPopup"
		).style.display = "flex";
	}

	function CloseChannelInfo() {
		document.getElementById(
			"channelInfoPopup"
		).style.display = "none";
	}

	</script>

</body>
</html>