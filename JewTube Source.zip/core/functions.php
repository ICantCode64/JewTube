<?php
function SqlQuery($sql) {
    global $conn;
    $result = $conn->query($sql);
    return $result;
}

function SafeVar($variable)  {
    global $conn;
    return mysqli_real_escape_string($conn, $variable);
}

function LoginAs($userid) {
    global $conn;

    $user = SqlQuery("SELECT * FROM users WHERE userid = '$userid'")->fetch_assoc();
    if (!$user) {
        return false;
    }

    $_SESSION["userid"] = $userid;
    $_SESSION["loggedin"] = true;

    return true;
}

function FormatNumber($number) {
    // K, M, B, T formatting
    if ($number < 1000) {
        return $number;
    } elseif ($number < 1000000) {
        return round($number / 1000) . 'K';
    } elseif ($number < 1000000000) {
        return round($number / 1000000) . 'M';
    } else {
        return round($number / 1000000000) . 'B';
    }
}

function FormatDateAgo($date) {

    $seconds = time() - strtotime($date);

    $minutes = round($seconds / 60);
    $hours = round($seconds / 3600);
    $days = round($seconds / 86400);
    $weeks = round($seconds / 604800);
    $months = round($seconds / 2592000);
    $years = round($seconds / 31536000);

    if ($years > 0) {
        return $years . ' year' . ($years != 1 ? 's' : '') . ' ago';
    }

    elseif ($months > 0) {
        return $months . ' month' . ($months != 1 ? 's' : '') . ' ago';
    }

    elseif ($weeks > 0) {
        return $weeks . ' week' . ($weeks != 1 ? 's' : '') . ' ago';
    }

    elseif ($days > 0) {
        return $days . ' day' . ($days != 1 ? 's' : '') . ' ago';
    }

    elseif ($hours > 0) {
        return $hours . ' hour' . ($hours != 1 ? 's' : '') . ' ago';
    }

    elseif ($minutes > 0) {
        return $minutes . ' minute' . ($minutes != 1 ? 's' : '') . ' ago';
    }

    elseif ($seconds > 0) {
        return $seconds . ' second' . ($seconds != 1 ? 's' : '') . ' ago';
    }

    else {
        return 'just now';
    }
}

function GetVideoDuration($file, $id = null) {

	if (!file_exists($file)) {
		return 0;
	}

	$cmd = "ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 " . escapeshellarg($file);

	$duration = trim(shell_exec($cmd));

	if (!is_numeric($duration)) {
		return 0;
	}

	$duration = (int) round($duration);

	if ($id !== null) {

		$id = (int) $id;

		SqlQuery("
			UPDATE videos
			SET duration = '$duration'
			WHERE videoid = '$id'
		");
	}

	return $duration;
}

function FormatDuration($seconds) {
	$hours = floor($seconds / 3600);
	$minutes = floor(($seconds % 3600) / 60);
	$secs = $seconds % 60;

	if ($hours > 0) {
		return sprintf("%d:%02d:%02d", $hours, $minutes, $secs);
	}

	return sprintf("%d:%02d", $minutes, $secs);
}
?>